@echo off
mkdir "c:\Users\u0167326\OneDrive - KU Leuven\Desktop\PHD Research\NNR\NNR\Rlib" 2>nul
cd /d "c:\Users\u0167326\OneDrive - KU Leuven\Desktop\PHD Research\NNR\NNR"
"R" CMD INSTALL -l "c:\Users\u0167326\OneDrive - KU Leuven\Desktop\PHD Research\NNR\NNR\Rlib" .
pause
