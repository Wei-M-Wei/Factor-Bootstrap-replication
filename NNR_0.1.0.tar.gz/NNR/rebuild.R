# Rebuild the NNR package
setwd("c:\\Users\\u0167326\\OneDrive - KU Leuven\\Desktop\\PHD Research\\NNR\\NNR")

# Clean and rebuild
devtools::clean_dll()
devtools::document()
devtools::load_all()

cat("Package rebuilt successfully!\n")
source("toy_example.R")
