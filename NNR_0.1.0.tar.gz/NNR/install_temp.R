dir.create('C:/Temp/NNR_Rlib', showWarnings=FALSE, recursive=TRUE)
setwd('c:/Users/u0167326/OneDrive - KU Leuven/Desktop/PHD Research/NNR/NNR')
system('R CMD INSTALL -l "C:/Temp/NNR_Rlib" .')
cat('INSTALL_FINISHED\n')
