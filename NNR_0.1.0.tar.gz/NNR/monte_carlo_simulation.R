# ============================================================
# Monte Carlo Simulation for Interactive Fixed Effects Panel
# Translated from MATLAB to R
# Uses NNRPanel_estimate for estimation
# Parallel processing enabled with foreach/doParallel
# ============================================================

library(NNR)
library(parallel)
library(foreach)
library(doParallel)
library(MASS)

# ============================================================
# PARAMETERS
# ============================================================
Tgrid <- c(20, 30, 40, 50)    # T values to test
N <- 100                       # Cross-sectional units
S <- 200                       # Number of simulation replications
num_bootstrap <- 199           # Bootstrap replications (0 = no bootstrap)
R_true <- 1                    # True number of latent factors
R_false <- 1                   # Overselection of factors (for estimation)
dimbeta <- 1                   # Dimension of beta
beta_true <- c(0.5)            # True beta
beta_test <- c(0)              # H0 for testing
model_type <- "logit"          # "logit" or "probit"
alpha <- 0.05                  # Significance level
tol <- 1e-6
maxiter <- 1000
r_s <- 0.2                     # Factor loading scale

# Number of cores for parallel
num_cores <- min(detectCores() - 1, 18)

# Setup parallel backend
cat("Setting up parallel cluster with", num_cores, "cores...\n")
cl <- makeCluster(num_cores)
registerDoParallel(cl)

cat("========================================\n")
cat("MONTE CARLO SIMULATION SETUP\n")
cat("========================================\n")
cat("N:", N, "\n")
cat("T grid:", Tgrid, "\n")
cat("Simulations (S):", S, "\n")
cat("True R:", R_true, "\n")
cat("True beta:", beta_true, "\n")
cat("Model:", model_type, "\n")
cat("Parallel cores:", num_cores, "\n\n")

# ============================================================
# STORAGE ARRAYS
# ============================================================
num_T <- length(Tgrid)

# Initialize result storage
results <- list(
  beta_mle = array(NA, dim = c(num_T, S, dimbeta)),
  beta_corr = array(NA, dim = c(num_T, S, dimbeta)),
  beta_bc_ana = array(NA, dim = c(num_T, S, dimbeta)),
  beta_bc_boot = array(NA, dim = c(num_T, S, dimbeta)),
  Var_beta = array(NA, dim = c(num_T, S, dimbeta)),
  coverage_mle = matrix(NA, num_T, dimbeta),
  coverage_corr = matrix(NA, num_T, dimbeta),
  coverage_ana = matrix(NA, num_T, dimbeta),
  coverage_boot = matrix(NA, num_T, dimbeta),
  reject_mle = matrix(NA, num_T, dimbeta),
  reject_corr = matrix(NA, num_T, dimbeta),
  reject_ana = matrix(NA, num_T, dimbeta),
  reject_boot = matrix(NA, num_T, dimbeta)
)

# ============================================================
# HELPER FUNCTIONS
# ============================================================

# Generate data for one simulation
generate_data <- function(N, T, R, beta, r_s, model_type) {
  dimbeta <- length(beta)
  
  # Generate factors
  lambda_i <- matrix(rnorm(N * R), N, R)
  f_t <- matrix(rnorm(T * R), T, R)
  alpha_true <- r_s * lambda_i %*% t(f_t)  # Interactive fixed effects
  
  # Generate covariates (correlated with factors)
  lambda_x <- matrix(rnorm(N * R), N, R)
  f_x <- matrix(rnorm(T * R), T, R)
  Xmat <- lambda_x %*% t(f_x)
  
  # Create X array (N x T x dimbeta)
  X_list <- list()
  X_array <- array(0, dim = c(N, T, dimbeta))
  for (k in 1:dimbeta) {
    X_array[, , k] <- Xmat + matrix(rnorm(N * T), N, T)
    X_list[[k]] <- X_array[, , k]
  }
  
  # Compute linear index
  Xtheta <- matrix(0, N, T)
  for (k in 1:dimbeta) {
    Xtheta <- Xtheta + X_array[, , k] * beta[k]
  }
  
  # Generate outcome
  if (model_type == "logit") {
    U <- matrix(runif(N * T), N, T)
    logistic_noise <- log(U / (1 - U))
    Y <- (Xtheta + alpha_true + logistic_noise > 0) * 1
  } else if (model_type == "probit") {
    noise <- matrix(rnorm(N * T), N, T)
    Y <- (Xtheta + alpha_true + noise > 0) * 1
  }
  
  # Convert to data_frame format [ID, Time, Y, X1, X2, ...]
  data_frame <- matrix(0, N * T, 3 + dimbeta)
  idx <- 1
  for (i in 1:N) {
    for (t in 1:T) {
      data_frame[idx, 1] <- i
      data_frame[idx, 2] <- t
      data_frame[idx, 3] <- Y[i, t]
      for (k in 1:dimbeta) {
        data_frame[idx, 3 + k] <- X_array[i, t, k]
      }
      idx <- idx + 1
    }
  }
  
  return(list(
    Y = Y,
    X = X_array,
    X_list = X_list,
    data_frame = data_frame,
    lambda_true = lambda_i,
    f_true = f_t,
    alpha_true = alpha_true
  ))
}

# Analytical bias correction (from your MATLAB code)
compute_analytical_bias <- function(Y, X_list, beta_mle, lambda_mle, f_mle, model_type) {
  N <- nrow(Y)
  T <- ncol(Y)
  dimbeta <- length(beta_mle)
  R <- ncol(lambda_mle)
  
  # Compute fitted values
  z_hat <- lambda_mle %*% t(f_mle)
  for (k in 1:dimbeta) {
    z_hat <- z_hat + X_list[[k]] * beta_mle[k]
  }
  
  # Compute derivatives based on model type
  if (model_type == "logit") {
    p_hat <- 1 / (1 + exp(-z_hat))
    d1 <- Y - p_hat
    d2 <- -p_hat * (1 - p_hat)
    d3 <- -p_hat * (1 - p_hat) * (1 - 2 * p_hat)
  } else if (model_type == "probit") {
    z_hat <- pmax(pmin(z_hat, 7), -7)
    Phi <- pnorm(z_hat)
    phi <- dnorm(z_hat)
    v <- Phi * (1 - Phi)
    v[v < 1e-10] <- 1e-10  # Avoid division by zero
    
    d1 <- ((Y - Phi) / v) * phi
    d2 <- -z_hat * d1 - (phi^2 / v) - (phi^2 * (Y - Phi) * (1 - 2 * Phi)) / (v^2)
    d3 <- -d1 - z_hat * d2 +
      (2 * z_hat * phi^2) / v + (phi^3 * (1 - 2 * Phi)) / (v^2) +
      (2 * z_hat * phi^2 * (Y - Phi) * (1 - 2 * Phi) + phi^3 * (1 - 2 * Phi) + 2 * phi^3 * (Y - Phi)) / (v^2) +
      (2 * phi^3 * (Y - Phi) * (1 - 2 * Phi)^2) / (v^3)
  }
  
  w_ij <- -d2  # Weights
  
  # Projection for Xi_hat (simplified version)
  # In full implementation, this would involve iterative projection
  Xi_hat <- array(0, dim = c(N, T, dimbeta))
  
  # X_tilde = X - Xi_hat
  X_tilde <- array(0, dim = c(N, T, dimbeta))
  for (k in 1:dimbeta) {
    X_tilde[, , k] <- X_list[[k]] - Xi_hat[, , k]
  }
  
  n_total <- N * T
  
  # Compute W_hat
  W_hat <- matrix(0, dimbeta, dimbeta)
  for (i in 1:N) {
    for (j in 1:T) {
      x_diff <- X_tilde[i, j, ]
      W_hat <- W_hat - (1 / n_total) * d2[i, j] * (x_diff %*% t(x_diff))
    }
  }
  
  # Compute B (bias from individual effects)
  B <- rep(0, dimbeta)
  for (i in 1:N) {
    H_i <- t(f_mle) %*% diag(d2[i, ]) %*% f_mle
    H_i_inv <- tryCatch(solve(H_i), error = function(e) ginv(H_i))
    
    for (j in 1:T) {
      quad_f_ij <- t(f_mle[j, ]) %*% H_i_inv %*% f_mle[j, ]
      term <- as.numeric(quad_f_ij) * (d1[i, j] * d2[i, j] + 0.5 * d3[i, j]) * X_tilde[i, j, ]
      B <- B - term / n_total
    }
  }
  
  # Compute D (bias from time effects)
  D <- rep(0, dimbeta)
  for (j in 1:T) {
    H_j <- t(lambda_mle) %*% diag(d2[, j]) %*% lambda_mle
    H_j_inv <- tryCatch(solve(H_j), error = function(e) ginv(H_j))
    
    for (i in 1:N) {
      quad_lambda_ij <- t(lambda_mle[i, ]) %*% H_j_inv %*% lambda_mle[i, ]
      term <- as.numeric(quad_lambda_ij) * (d1[i, j] * d2[i, j] + 0.5 * d3[i, j]) * X_tilde[i, j, ]
      D <- D - term / n_total
    }
  }
  
  # Bias-corrected estimate
  W_hat_inv <- tryCatch(solve(W_hat), error = function(e) ginv(W_hat))
  beta_corrected <- beta_mle - W_hat_inv %*% (B + D)
  
  return(as.vector(beta_corrected))
}

# Bootstrap bias correction
bootstrap_bias_correction <- function(Y, X_list, beta_mle, lambda_mle, f_mle, 
                                       model_type, num_bootstrap, N, T, R, dimbeta) {
  
  # Fitted values
  z_fit <- lambda_mle %*% t(f_mle)
  for (k in 1:dimbeta) {
    z_fit <- z_fit + X_list[[k]] * beta_mle[k]
  }
  
  beta_boot <- matrix(NA, dimbeta, num_bootstrap)
  
  for (b in 1:num_bootstrap) {
    # Generate bootstrap sample
    if (model_type == "logit") {
      U <- matrix(runif(N * T), N, T)
      logistic_noise <- log(U / (1 - U))
      Y_boot <- (z_fit + logistic_noise > 0) * 1
    } else if (model_type == "probit") {
      noise <- matrix(rnorm(N * T), N, T)
      Y_boot <- (z_fit + noise > 0) * 1
    }
    
    # Create data_frame for bootstrap sample
    data_frame_boot <- matrix(0, N * T, 3 + dimbeta)
    idx <- 1
    for (i in 1:N) {
      for (t in 1:T) {
        data_frame_boot[idx, 1] <- i
        data_frame_boot[idx, 2] <- t
        data_frame_boot[idx, 3] <- Y_boot[i, t]
        for (k in 1:dimbeta) {
          data_frame_boot[idx, 3 + k] <- X_list[[k]][i, t]
        }
        idx <- idx + 1
      }
    }
    
    # Estimate on bootstrap sample
    tryCatch({
      result_boot <- NNRPanel_estimate(
        data_frame = data_frame_boot,
        func = model_type,
        delta = 0.05,
        R_max = R + 2,
        R_true = R,
        s = 10,
        iter_max = 100,
        tol = 1e-6
      )
      beta_boot[, b] <- result_boot$beta_fe_data[1:dimbeta]
    }, error = function(e) {
      beta_boot[, b] <- NA
    })
  }
  
  # Compute bootstrap bias correction
  beta_boot_mean <- rowMeans(beta_boot, na.rm = TRUE)
  beta_bc <- 2 * beta_mle - beta_boot_mean
  
  # Bootstrap CI
  ci_low <- apply(beta_boot - beta_mle, 1, quantile, probs = alpha/2, na.rm = TRUE)
  ci_high <- apply(beta_boot - beta_mle, 1, quantile, probs = 1 - alpha/2, na.rm = TRUE)
  
  return(list(
    beta_bc = beta_bc,
    ci_low = beta_mle - ci_high,
    ci_high = beta_mle - ci_low,
    beta_boot = beta_boot
  ))
}

# ============================================================
# SINGLE SIMULATION FUNCTION
# ============================================================
run_single_simulation <- function(sim_id, N, T, R_true, R_est, beta_true, r_s, 
                                   model_type, num_bootstrap, alpha) {
  
  dimbeta <- length(beta_true)
  
  # Generate data
  data <- generate_data(N, T, R_true, beta_true, r_s, model_type)
  
  # Run NNRPanel_estimate
  result <- tryCatch({
    NNRPanel_estimate(
      data_frame = data$data_frame,
      func = model_type,
      delta = 0.05,
      R_max = R_est + 2,
      R_true = R_est,
      s = 10,
      iter_max = 100,
      tol = 1e-6
    )
  }, error = function(e) {
    return(NULL)
  })
  
  if (is.null(result)) {
    return(list(
      beta_mle = rep(NA, dimbeta),
      beta_corr = rep(NA, dimbeta),
      beta_bc_ana = rep(NA, dimbeta),
      beta_bc_boot = rep(NA, dimbeta),
      se_beta = rep(NA, dimbeta),
      boot_ci_low = rep(NA, dimbeta),
      boot_ci_high = rep(NA, dimbeta)
    ))
  }
  
  # Extract MLE estimate - use beta_fe (R_true based) if available, else beta_fe_data
  beta_mle <- if (!is.null(result$beta_fe)) {
    result$beta_fe[1:dimbeta]
  } else {
    result$beta_fe_data[1:dimbeta]
  }
  
  # Extract bias-corrected estimate (split-panel jackknife) - use R_true based if available
  beta_corr <- if (!is.null(result$beta_corr_sp)) {
    result$beta_corr_sp[1:dimbeta]
  } else {
    result$beta_corr_sp_data[1:dimbeta]
  }
  
  # Standard error - use R_true based if available
  se_beta <- if (!is.null(result$std_beta_corr)) {
    result$std_beta_corr[1:dimbeta]
  } else if (!is.null(result$std_beta_corr_data)) {
    result$std_beta_corr_data[1:dimbeta]
  } else {
    rep(NA, dimbeta)
  }
  
  # Analytical bias correction - use R_true based if available
  beta_bc_ana <- if (!is.null(result$beta_corr)) {
    result$beta_corr[1:dimbeta]
  } else {
    result$beta_corr_data[1:dimbeta]
  }
  
  # Bootstrap (optional - computationally expensive)
  beta_bc_boot <- rep(NA, dimbeta)
  boot_ci_low <- rep(NA, dimbeta)
  boot_ci_high <- rep(NA, dimbeta)
  
  if (num_bootstrap > 0) {
    # Get L and R from the estimation (need to extract from internals)
    # For now, skip bootstrap to save time
    # boot_result <- bootstrap_bias_correction(...)
  }
  
  return(list(
    beta_mle = beta_mle,
    beta_corr = beta_corr,
    beta_bc_ana = beta_bc_ana,
    beta_bc_boot = beta_bc_boot,
    se_beta = se_beta,
    boot_ci_low = boot_ci_low,
    boot_ci_high = boot_ci_high
  ))
}

# ============================================================
# MAIN SIMULATION LOOP (PARALLELIZED)
# ============================================================

cat("Starting simulations...\n\n")

for (t_idx in 1:num_T) {
  T_val <- Tgrid[t_idx]
  cat(sprintf("================ Processing T = %d ================\n", T_val))
  
  start_time <- Sys.time()
  
  # Run simulations in parallel using foreach
  sim_results <- foreach(
    jsim = 1:S,
    .packages = c("NNR", "MASS"),
    .combine = 'rbind',
    .errorhandling = 'pass',
    .export = c("generate_data", "run_single_simulation", "compute_analytical_bias")
  ) %dopar% {
    
    sim_result <- run_single_simulation(
      sim_id = jsim,
      N = N,
      T = T_val,
      R_true = R_true,
      R_est = R_false,
      beta_true = beta_true,
      r_s = r_s,
      model_type = model_type,
      num_bootstrap = 0,  # Set to num_bootstrap for bootstrap
      alpha = alpha
    )
    
    # Return results as a vector (to combine with rbind)
    c(
      beta_mle = sim_result$beta_mle,
      beta_corr = sim_result$beta_corr,
      beta_bc_ana = sim_result$beta_bc_ana,
      se_beta = sim_result$se_beta
    )
  }
  
  end_time <- Sys.time()
  elapsed <- difftime(end_time, start_time, units = "secs")
  cat(sprintf("  Completed %d simulations in %.1f seconds\n", S, as.numeric(elapsed)))
  
  # Convert results back to matrices
  # sim_results is S x (4*dimbeta) matrix
  beta_mle_store <- matrix(sim_results[, 1:dimbeta], S, dimbeta)
  beta_corr_store <- matrix(sim_results[, (dimbeta+1):(2*dimbeta)], S, dimbeta)
  beta_ana_store <- matrix(sim_results[, (2*dimbeta+1):(3*dimbeta)], S, dimbeta)
  se_store <- matrix(sim_results[, (3*dimbeta+1):(4*dimbeta)], S, dimbeta)
  
  # Store results
  results$beta_mle[t_idx, , ] <- beta_mle_store
  results$beta_corr[t_idx, , ] <- beta_corr_store
  results$beta_bc_ana[t_idx, , ] <- beta_ana_store
  results$Var_beta[t_idx, , ] <- se_store^2
  
  # Compute coverage and rejection rates
  z_alpha <- qnorm(1 - alpha/2)
  
  for (j in 1:dimbeta) {
    se_j <- se_store[, j]
    
    # MLE coverage
    ci_low <- beta_mle_store[, j] - z_alpha * se_j
    ci_high <- beta_mle_store[, j] + z_alpha * se_j
    results$coverage_mle[t_idx, j] <- mean(beta_true[j] >= ci_low & beta_true[j] <= ci_high, na.rm = TRUE)
    results$reject_mle[t_idx, j] <- mean(beta_test[j] < ci_low | beta_test[j] > ci_high, na.rm = TRUE)
    
    # Corrected (split-panel jackknife) coverage
    ci_low <- beta_corr_store[, j] - z_alpha * se_j
    ci_high <- beta_corr_store[, j] + z_alpha * se_j
    results$coverage_corr[t_idx, j] <- mean(beta_true[j] >= ci_low & beta_true[j] <= ci_high, na.rm = TRUE)
    results$reject_corr[t_idx, j] <- mean(beta_test[j] < ci_low | beta_test[j] > ci_high, na.rm = TRUE)
    
    # Analytical BC coverage
    ci_low <- beta_ana_store[, j] - z_alpha * se_j
    ci_high <- beta_ana_store[, j] + z_alpha * se_j
    results$coverage_ana[t_idx, j] <- mean(beta_true[j] >= ci_low & beta_true[j] <= ci_high, na.rm = TRUE)
    results$reject_ana[t_idx, j] <- mean(beta_test[j] < ci_low | beta_test[j] > ci_high, na.rm = TRUE)
  }
}

# ============================================================
# PRINT RESULTS
# ============================================================

cat("\n========================================\n")
cat("SIMULATION RESULTS\n")
cat("========================================\n")
cat(sprintf("Model: %s, N = %d, S = %d\n", model_type, N, S))
cat(sprintf("True beta: %s\n", paste(beta_true, collapse = ", ")))
cat(sprintf("H0: beta = %s\n\n", paste(beta_test, collapse = ", ")))

cat("================================================================================\n")
cat("T\tMethod     \tBias\t\tStd\t\tCR\t\tRej\n")
cat("--------------------------------------------------------------------------------\n")

for (t_idx in 1:num_T) {
  T_val <- Tgrid[t_idx]
  
  # MLE
  beta_mle <- results$beta_mle[t_idx, , 1]
  mean_mle <- mean(beta_mle, na.rm = TRUE)
  std_mle <- sd(beta_mle, na.rm = TRUE)
  bias_mle <- (mean_mle - beta_true[1]) / abs(beta_true[1])
  
  cat(sprintf("%d\tMLE       \t%.4f\t\t%.4f\t\t%.3f\t\t%.3f\n",
              T_val, bias_mle, std_mle, results$coverage_mle[t_idx, 1], results$reject_mle[t_idx, 1]))
  
  # Split-panel Jackknife
  beta_corr <- results$beta_corr[t_idx, , 1]
  mean_corr <- mean(beta_corr, na.rm = TRUE)
  std_corr <- sd(beta_corr, na.rm = TRUE)
  bias_corr <- (mean_corr - beta_true[1]) / abs(beta_true[1])
  
  cat(sprintf("\tSplitPJ   \t%.4f\t\t%.4f\t\t%.3f\t\t%.3f\n",
              bias_corr, std_corr, results$coverage_corr[t_idx, 1], results$reject_corr[t_idx, 1]))
  
  # Analytical BC
  beta_ana <- results$beta_bc_ana[t_idx, , 1]
  beta_ana[abs(beta_ana) > 3] <- NA  # Remove outliers
  mean_ana <- mean(beta_ana, na.rm = TRUE)
  std_ana <- sd(beta_ana, na.rm = TRUE)
  bias_ana <- (mean_ana - beta_true[1]) / abs(beta_true[1])
  
  cat(sprintf("\tAnalytical\t%.4f\t\t%.4f\t\t%.3f\t\t%.3f\n",
              bias_ana, std_ana, results$coverage_ana[t_idx, 1], results$reject_ana[t_idx, 1]))
  
  cat("--------------------------------------------------------------------------------\n")
}

cat("\n*** SIMULATION COMPLETE ***\n")

# Cleanup parallel cluster
stopCluster(cl)
cat("Parallel cluster stopped.\n")

# Save results
# save(results, file = sprintf("%s_results_N%d_S%d.RData", model_type, N, S))
