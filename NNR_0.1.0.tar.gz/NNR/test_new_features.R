# Test new features: R_true_only and factor/loading returns
library(NNR)

set.seed(123)

# Generate test data
N <- 50
T <- 50
num_factor <- 1
beta_true <- 1

# Generate factors and loadings
L <- matrix(rnorm(N * num_factor), N, num_factor)
R <- matrix(rnorm(T * num_factor), T, num_factor)

# Generate covariate
X <- list(matrix(rnorm(N * T), N, T))

# Generate outcome
Theta <- L %*% t(R)
index <- X[[1]] * beta_true + Theta
P <- 1 / (1 + exp(-index))
Y <- matrix(rbinom(N * T, 1, P), N, T)

# Convert to data frame
data_frame <- cbind(
  rep(1:N, each = T),
  rep(1:T, N),
  as.vector(t(Y)),
  as.vector(t(X[[1]]))
)

cat("=== Testing R_true_only = TRUE ===\n")
t1 <- Sys.time()
result <- NNRPanel_estimate(data_frame, func = "logit", R_true = 1, R_true_only = TRUE)
t2 <- Sys.time()
cat("Time with R_true_only = TRUE:", round(difftime(t2, t1, units = "secs"), 2), "seconds\n")

cat("\nResults:\n")
cat("  beta_fe:", result$beta_fe, "\n")
cat("  beta_corr:", result$beta_corr, "\n")
cat("  L_fe dimensions:", dim(result$L_fe), "\n")
cat("  R_fe dimensions:", dim(result$R_fe), "\n")

cat("\n=== Verify L_fe and R_fe are returned ===\n")
cat("L_fe first 5 rows:\n")
print(head(result$L_fe, 5))
cat("\nR_fe first 5 rows:\n")
print(head(result$R_fe, 5))

cat("\n=== Test passed! ===\n")
