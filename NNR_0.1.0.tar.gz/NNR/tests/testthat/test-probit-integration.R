test_that("NNRPanel_estimate runs for probit and returns expected structure", {
  skip_on_cran()
  set.seed(1)
  dat <- gen_data_probit(N = 20, T = 20, num_factor = 1, num_Z = 1, beta = c(0.2))
  df <- list_to_data_frame(dat)
  # Only run a light-weight call: small iter_max and s to keep runtime small
  res <- NNRPanel_estimate(data_frame = df, func = "probit", delta = 0.05, R_max = 2, s = 1, iter_max = 10, tol = 1e-6)
  expect_true(is.list(res))
  expect_true("beta_nnr" %in% names(res))
  expect_true("beta_fe_data" %in% names(res))
})