library(NNR)

# Small finite-difference checks for probit derivatives (LR, N=1,T=1)

# helper
Phi <- function(x) pnorm(x)
logl <- function(eta, y){
  p = Phi(eta)
  p = pmax(pmin(p, 1 - 1e-12), 1e-12)
  y * log(p) + (1 - y) * log(1 - p)
}

check_at <- function(eta, y){
  # construct inputs for Compute_*_with_LR: N=1,T=1
  X = list()
  beta = numeric(0)
  L = matrix(eta, nrow=1, ncol=1)
  R = matrix(1, nrow=1, ncol=1)
  Y = matrix(y, nrow=1, ncol=1)

  # analytic (call internal registered C symbols to avoid namespace export issues)
  a1 = as.numeric(.Call("_NNR_Compute_first_order_probit_with_LR", X, Y, beta, L, R))[1]
  a2 = as.numeric(.Call("_NNR_Compute_second_order_probit_with_LR", X, Y, beta, L, R))[1]
  a3 = as.numeric(.Call("_NNR_Compute_third_order_probit_with_LR", X, Y, beta, L, R))[1]

  # numeric differences: try several h and pick numeric values with smallest relative error where possible
  hs = c(1e-1,1e-2,1e-3,1e-4,1e-5,1e-6)
  n1s = numeric(length(hs)); n2s = numeric(length(hs)); n3s = numeric(length(hs))
  for (k in seq_along(hs)){
    h = hs[k]
    f0 = logl(eta, y)
    fph = logl(eta + h, y)
    fmh = logl(eta - h, y)
    f2ph = logl(eta + 2*h, y)
    f2mh = logl(eta - 2*h, y)
    n1s[k] = (fph - fmh) / (2*h)
    n2s[k] = (fph - 2*f0 + fmh) / (h*h)
    n3s[k] = (-f2ph + 2*fph - 2*fmh + f2mh) / (2 * h^3)
  }
  # pick the hs entry where relative error for first+second is minimal (heuristic)
  rel1 = abs((a1 - n1s)/pmax(1e-12, abs(n1s)))
  rel2 = abs((a2 - n2s)/pmax(1e-12, abs(n2s)))
  score = rel1 + rel2
  best = which.min(score)
  n1 = n1s[best]; n2 = n2s[best]; n3 = n3s[best]; h_used = hs[best]

  cat(sprintf("eta=%.6g y=%d\n", eta, y))
  cat(sprintf(" first: analytic=%.12g numeric=%.12g rel_err=%.3g\n", a1, n1, abs((a1-n1)/pmax(1e-12,abs(n1)))))
  cat(sprintf(" second: analytic=%.12g numeric=%.12g rel_err=%.3g\n", a2, n2, abs((a2-n2)/pmax(1e-12,abs(n2)))))
  cat(sprintf(" third: analytic=%.12g numeric=%.12g rel_err=%.3g\n", a3, n3, abs((a3-n3)/pmax(1e-12,abs(n3)))))
  cat("--------------------------\n")
}

etas = c(-5,-2,-1,-0.5,0,0.5,1,2,5)
for(y in c(0,1)){
  for(eta in etas) check_at(eta, y)
}
