library(pkgload)
load_all()
set.seed(42)
dat <- gen_data_probit(N=30, T=30, num_factor=1, num_Z=1, beta=c(0.2))
dl <- data_frame_to_list(list_to_data_frame(dat))
X <- dl$X
Y <- dl$Y
fitres <- fit_probit(X, Y, phi=1, s=1, iter_max=30, tol=1e-6)
LR <- Low_rank_appro(fitres$Theta_est, 1)
fefit <- MLE_probit(X, Y, fitres$beta_est, LR$L, LR$R, s=1, iter_max=40, tol=1e-6)

fo <- Compute_first_order_probit_with_LR(X, Y, fefit$beta_est, fefit$L_est, fefit$R_est)
so <- Compute_second_order_probit_with_LR(X, Y, fefit$beta_est, fefit$L_est, fefit$R_est)

to <- Compute_third_order_probit_with_LR(X, Y, fefit$beta_est, fefit$L_est, fefit$R_est)

stats <- function(M){
  m <- as.numeric(M)
  c(min=min(m, na.rm=TRUE), max=max(m, na.rm=TRUE), mean=mean(m, na.rm=TRUE), sd=sd(m, na.rm=TRUE), sum_abs=sum(abs(m), na.rm=TRUE), norm2=sqrt(sum(m*m, na.rm=TRUE)), zeros=sum(abs(m) < 1e-16), nas=sum(is.na(m)))
}

cat('Derivative summaries:\n')
print(list(first=stats(fo), second=stats(so), third=stats(to)))

bc <- Compute_bias_corr_probit(Y, X, fefit$beta_est, fefit$L_est, fefit$R_est, 0)
cat('\nBeta (FE) and bias-corrected:\n')
print(list(beta_fe=fefit$beta_est, beta_corr=bc$beta_corr, diff=bc$beta_corr - fefit$beta_est))

cat('\nB/D/W stats:\n')
print(list(B=stats(bc$B_est), D=stats(bc$D_est), W=stats(bc$W_est)))

cat('\nCov diagonal and std_est stats:\n')
print(list(Cov_diag_min=min(diag(bc$Cov_est)), Cov_diag_max=max(diag(bc$Cov_est)), std_stats=stats(bc$std_est)))
