##' NNR: Neural Network Regression package
##'
##' Package documentation for the NNR package.
##'
#' @useDynLib NNR, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @import RcppEigen
#' @docType package
#' @name NNR
NULL
