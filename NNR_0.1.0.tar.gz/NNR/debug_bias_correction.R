# Debug script for analytical bias correction
# Testing why B_est and D_est are zero

library(NNR)
library(fixest)
set.seed(123)

# Small example
N <- 20
T <- 15
R <- 1

# Generate simple data
lambda <- matrix(rnorm(N * R), N, R)
f <- matrix(rnorm(T * R), T, R)
alpha <- lambda %*% t(f)

X1 <- matrix(rnorm(N * T), N, T)
beta_true <- 1.0
eta <- beta_true * X1 + alpha
prob <- 1 / (1 + exp(-eta))
Y <- matrix(rbinom(N * T, 1, prob), N, T)

# Create data frame
df <- cbind(rep(1:N, each = T), rep(1:T, N), as.vector(t(Y)), as.vector(t(X1)))

cat("Running NNRPanel_estimate...\n")
result <- NNRPanel_estimate(
  data_frame = df,
  func = "logit",
  delta = 0.05,
  R_max = 3,
  R_true = R,
  s = 10,
  iter_max = 1000,
  tol = 1e-6
)

cat("\n=== Bias Correction Components ===\n")
cat("B_est:\n")
print(result)

# Now let's manually test the weighted projection
cat("\n=== Manual Test of Compute_weighted ===\n")

# Get the estimated L and R matrices
data_list <- data_frame_to_list(df)
Y_mat <- data_list$Y
X_list <- data_list$X

# Get MLE estimates first (similar to what NNRPanel does internally)
# We need to replicate what the bias correction does

# Test fixest formula syntax
cat("\nTesting fixest formula syntax...\n")

# Create test data for fixest
id_vec <- rep(1:N, each = T)
time_vec <- rep(1:T, N)
X_vec <- as.vector(t(X1))

# Replicate Lambda and Gamma as in C++ code
Lambda_rep <- do.call(rbind, replicate(T, lambda, simplify = FALSE))
Gamma_rep <- matrix(0, N * T, R)
for (t in 1:T) {
  rows <- ((t-1)*N + 1):(t*N)
  Gamma_rep[rows, ] <- matrix(rep(f[t, ], N), N, R, byrow = TRUE)
}

test_df <- data.frame(
  X = X_vec,
  id = factor(id_vec),
  time = factor(time_vec),
  Lambda1 = Lambda_rep[, 1],
  Gamma1 = Gamma_rep[, 1]
)

cat("Test data frame structure:\n")
print(head(test_df, 10))

# Test the fixest formula
cat("\nTrying fixest formula: X ~ 0 | time[Lambda1] + id[Gamma1]\n")
tryCatch({
  fit <- feols(X ~ 0 | time[Lambda1] + id[Gamma1], data = test_df)
  cat("Residuals range:", range(residuals(fit)), "\n")
  cat("Residuals mean:", mean(residuals(fit)), "\n")
  cat("Residuals sd:", sd(residuals(fit)), "\n")
}, error = function(e) {
  cat("ERROR:", e$message, "\n")
})

# Try alternative formulation
cat("\nTrying alternative: X ~ Lambda1:factor(time) + Gamma1:factor(id)\n")
tryCatch({
  fit2 <- feols(X ~ Lambda1:factor(time) + Gamma1:factor(id), data = test_df)
  cat("Residuals range:", range(residuals(fit2)), "\n")
  cat("Residuals mean:", mean(residuals(fit2)), "\n")
  cat("Residuals sd:", sd(residuals(fit2)), "\n")
}, error = function(e) {
  cat("ERROR:", e$message, "\n")
})

# Simple projection without fixest
cat("\n=== Simple Manual Projection ===\n")
# X_tilde = X - projection onto factor space
# For factor model: X = Lambda_i' * delta_t + Gamma_t' * mu_i + X_tilde

# Create design matrices for projection
D_lambda <- model.matrix(~ factor(time):Lambda1 - 1, data = test_df)
D_gamma <- model.matrix(~ factor(id):Gamma1 - 1, data = test_df)
D_full <- cbind(D_lambda, D_gamma)

cat("Design matrix dimensions:", dim(D_full), "\n")

# Project X onto factor space
projection <- D_full %*% solve(t(D_full) %*% D_full + 1e-6 * diag(ncol(D_full))) %*% t(D_full) %*% X_vec
X_residual <- X_vec - projection

cat("X_residual range:", range(X_residual), "\n")
cat("X_residual sd:", sd(X_residual), "\n")
cat("Original X sd:", sd(X_vec), "\n")
cat("Ratio (residual/original):", sd(X_residual) / sd(X_vec), "\n")
