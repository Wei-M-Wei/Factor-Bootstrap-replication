# Test script for NNR package
# Small interactive factor model with known parameters

# Load the package in development mode
devtools::load_all()

set.seed(42)

# Parameters
N <- 20      # Number of individuals
T <- 25      # Number of time periods
num_factor <- 2
num_X <- 2
beta_true <- c(1, 1)  # True coefficient

# Generate factor structure
# L: N x num_factor (individual factors)
# R: T x num_factor (time factors)
L_true <- matrix(rnorm(N * num_factor, mean = 0, sd = 1), N, num_factor)
R_true <- matrix(rnorm(T * num_factor, mean = 0, sd = 1), T, num_factor)

# Interactive fixed effects (low-rank component)
Lambda_true <- L_true %*% t(R_true)

# Generate covariates
X_list <- list()
for (j in 1:num_X) {
  X_list[[j]] <- matrix(rnorm(N * T, mean = 0, sd = 1), N, T)
}

# Generate linear index
index <- Lambda_true
for (j in 1:num_X) {
  index <- index + beta_true[j] * X_list[[j]]
}

# Generate outcome: Logit model
# P(Y = 1 | X) = 1 / (1 + exp(-index))
prob <- 1 / (1 + exp(-index))
Y <- matrix(rbinom(N * T, size = 1, prob = as.vector(prob)), N, T)

# Convert to data_frame format
# Columns: ID, Time, Y, X1, X2, ...
data_frame <- matrix(0, N * T, 3 + num_X)  # Fixed: 3 + num_X instead of 2 + num_X
data_frame[, 1] <- rep(1:N, each = T)           # Individual ID
data_frame[, 2] <- rep(1:T, times = N)          # Time period
data_frame[, 3] <- as.vector(t(Y))              # Outcome
for (j in 1:num_X) {
  data_frame[, 3 + j] <- as.vector(t(X_list[[j]]))  # Covariates
}

# Convert to data frame for easier viewing
data_frame_df <- as.data.frame(data_frame)
colnames(data_frame_df) <- c("id", "time", "Y", paste0("X", 1:num_X))

cat("Data summary:\n")
cat("N =", N, ", T =", T, "\n")
cat("True beta:", beta_true, "\n")
cat("Number of factors:", num_factor, "\n")
cat("Outcome (Y) distribution:\n")
print(table(data_frame_df$Y))

cat("\n\nFirst few rows of data:\n")
print(head(data_frame_df, 10))

# Fit the model
cat("\n\nFitting NNRPanel_estimate model...\n")

result <- NNRPanel_estimate(
  data_frame = data_frame,
  func = "logit",
  delta = 0.05,
  R_max = 5,
  R_true = num_factor,
  s = 10,
  iter_max = 100,
  tol = 1e-6
)

# Display results
cat("\n\n========== RESULTS ==========\n")
cat("\nTrue beta:", beta_true, "\n")
cat("NNR beta estimate:", result$beta_nnr[1:num_X], "\n")
cat("\nEstimated number of factors:", result$num_factor_est, "\n")
cat("True number of factors:", num_factor, "\n")

if (!is.null(result$beta_fe)) {
  cat("\nbeta_fe (with R_true):", result$beta_fe[1:num_X], "\n")
}

if (!is.null(result$beta_corr)) {
  cat("beta_corr (analytical bias correction):", result$beta_corr[1:num_X], "\n")
}

if (!is.null(result$beta_corr_sp)) {
  cat("beta_corr_sp (sample-split bias correction):", result$beta_corr_sp[1:num_X], "\n")
}

cat("\nFE estimates with data-driven rank:")
cat("\nbeta_fe_data:", result$beta_fe_data[1:num_X], "\n")
cat("beta_corr_data:", result$beta_corr_data[1:num_X], "\n")
cat("beta_corr_sp_data:", result$beta_corr_sp_data[1:num_X], "\n")

# Compute errors
cat("\n\n========== ESTIMATION ERRORS ==========\n")
cat("NNR estimation error:", sqrt(sum((result$beta_nnr[1:num_X] - beta_true)^2)), "\n")
if (!is.null(result$beta_fe)) {
  cat("FE estimation error (R_true):", sqrt(sum((result$beta_fe[1:num_X] - beta_true)^2)), "\n")
}
if (!is.null(result$beta_corr)) {
  cat("BC estimation error (R_true):", sqrt(sum((result$beta_corr[1:num_X] - beta_true)^2)), "\n")
}
if (!is.null(result$beta_corr_sp)) {
  cat("SSBC estimation error (R_true):", sqrt(sum((result$beta_corr_sp[1:num_X] - beta_true)^2)), "\n")
}

cat("\nFE estimation error (data-driven):", sqrt(sum((result$beta_fe_data[1:num_X] - beta_true)^2)), "\n")
cat("BC estimation error (data-driven):", sqrt(sum((result$beta_corr_data[1:num_X] - beta_true)^2)), "\n")
cat("SSBC estimation error (data-driven):", sqrt(sum((result$beta_corr_sp_data[1:num_X] - beta_true)^2)), "\n")
