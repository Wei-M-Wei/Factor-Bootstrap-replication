library(pkgload)
load_all()
set.seed(42)
dat <- gen_data_probit(N=30, T=30, num_factor=1, num_Z=1, beta=c(0.2))
dl <- data_frame_to_list(list_to_data_frame(dat))
X <- dl$X
Y <- dl$Y
cat('X class:', class(X), ' length:', length(X), '\n')
if (length(X)>0) {
  for (i in seq_along(X)){
    cat('X[[',i,']] class:', class(X[[i]]), ' typeof:', typeof(X[[i]]), ' dim:', if(!is.null(dim(X[[i]]))) paste(dim(X[[i]]), collapse='x') else 'NULL', '\n')
  }
}
cat('Starting fit_probit...\n')
fitres <- tryCatch({
  fit_probit(X, Y, phi=1, s=1, iter_max=30, tol=1e-6)
}, error = function(e){
  cat('fit_probit ERROR:\n')
  print(e)
  NULL
})
cat('fitres is null? ', is.null(fitres), '\n')
if (!is.null(fitres)) cat('fit_probit succeeded\n')

if (!is.null(fitres)){
  cat('Running MLE_probit...\n')
  LR <- Low_rank_appro(fitres$Theta_est, 1)
  L <- LR$L; R <- LR$R; beta_0 <- fitres$beta_est
  fefit <- tryCatch({
    MLE_probit(X, Y, beta_0, L, R, s=1, iter_max=40, tol=1e-6)
  }, error=function(e){cat('MLE_probit ERROR:\n'); print(e); NULL})
  cat('fefit is null? ', is.null(fefit), '\n')
  if (!is.null(fefit)){
    cat('Computing first/second/third order matrices separately...\n')
    fo <- tryCatch({Compute_first_order_probit_with_LR(X, Y, fefit$beta_est, fefit$L_est, fefit$R_est)}, error=function(e){cat('first_order ERROR:\n'); cat(conditionMessage(e), '\n'); NULL})
    so <- tryCatch({Compute_second_order_probit_with_LR(X, Y, fefit$beta_est, fefit$L_est, fefit$R_est)}, error=function(e){cat('second_order ERROR:\n'); cat(conditionMessage(e), '\n'); NULL})
    to <- tryCatch({Compute_third_order_probit_with_LR(X, Y, fefit$beta_est, fefit$L_est, fefit$R_est)}, error=function(e){cat('third_order ERROR:\n'); cat(conditionMessage(e), '\n'); NULL})
    cat('first/second/third nulls:', is.null(fo), is.null(so), is.null(to), '\n')
    if (!is.null(so)){
      cat('Calling Create_X_res to check X_res...\n')
      xr <- tryCatch({Create_X_res(X, fefit$L_est, fefit$R_est, so)}, error=function(e){cat('Create_X_res ERROR:\n'); cat(conditionMessage(e), '\n'); NULL})
      cat('X_res null?', is.null(xr), '\n')

      cat('Reconstructing df in R and calling fixest::feols directly to reproduce error...\n')
      tryCatch({
        N <- nrow(X[[1]]); T <- ncol(X[[1]])
        X_vec <- as.vector(X[[1]])
        id <- rep(0:(N-1), times=T)
        time <- rep(0:(T-1), each=N)
        Lambda_rep <- as.numeric(fefit$L_est)
        Gamma_rep <- as.numeric(fefit$R_est)
        df <- data.frame(X = X_vec, id = id, time = time)
        num_factor <- ncol(fefit$L_est)
        for (r in 1:num_factor){
          df[[paste0('Lambda', r)]] <- Lambda_rep[((1:T)-1)*N + (1:N)]
          df[[paste0('Gamma', r)]] <- rep(fefit$R_est[r,], each=N)
        }
        formula_str <- paste0('X ~ 0 |', paste0(paste0('time[Lambda', 1:num_factor, ']'), collapse=' + '), ' + ', paste0(paste0('id[Gamma', 1:num_factor, ']'), collapse=' + '))
        cat('formula_str=', formula_str, '\n')
        res <- tryCatch({fixest::feols(as.formula(formula_str), data=df, weights=as.vector(so))}, error=function(e){cat('feols direct ERROR:\n'); cat(conditionMessage(e), '\n'); NULL})
        print(class(res))
      }, error=function(e){cat('reconstruct feols ERROR:', conditionMessage(e), '\n')})
    }

    cat('Calling Compute_bias_corr_probit...\n')
    bc <- tryCatch({
      Compute_bias_corr_probit(Y, X, fefit$beta_est, fefit$L_est, fefit$R_est, 0)
    }, error=function(e){cat('Compute_bias_corr_probit ERROR:\n'); cat(conditionMessage(e), '\n'); NULL})
    cat('bc is null? ', is.null(bc), '\n')
    if (!is.null(bc)) print(names(bc))
  }
}
