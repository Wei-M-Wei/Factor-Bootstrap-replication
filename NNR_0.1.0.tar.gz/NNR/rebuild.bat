@echo off
cd /d "c:\Users\u0167326\OneDrive - KU Leuven\Desktop\PHD Research\NNR\NNR"
"C:\Users\u0167326\AppData\Local\Programs\R\R-4.3.2\bin\Rscript.exe" rebuild.R
