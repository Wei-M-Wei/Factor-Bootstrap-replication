.libPaths(c('Rlib', .libPaths()))
library(magrittr)
library(NNR)
set.seed(1)
run_exp <- function(N,T){
  dat<-NNR:::gen_data_probit(N=N,T=T,num_factor=1,num_Z=1,beta=c(0.2))
  df<-NNR:::list_to_data_frame(dat)
  res<-NNR::NNRPanel_estimate(data_frame=df, func='probit', delta=0.05, R_max=2, s=1, iter_max=200, tol=1e-6)
  return(list(N=N,T=T,res=res))
}
small <- run_exp(20,20)
large <- run_exp(100,100)
res_lines <- c(
  sprintf('SMALL N=%d T=%d', small$N, small$T),
  sprintf(' bias_nnr= %.6f', small$res$beta_nnr-0.2),
  sprintf(' bias_fe_data= %.6f', small$res$beta_fe_data-0.2),
  sprintf(' bias_corr_data= %.6f', small$res$beta_corr_data-0.2),
  sprintf(' bias_corr_sp_data= %.6f', small$res$beta_corr_sp_data-0.2),
  '',
  sprintf('LARGE N=%d T=%d', large$N, large$T),
  sprintf(' bias_nnr= %.6f', large$res$beta_nnr-0.2),
  sprintf(' bias_fe_data= %.6f', large$res$beta_fe_data-0.2),
  sprintf(' bias_corr_data= %.6f', large$res$beta_corr_data-0.2),
  sprintf(' bias_corr_sp_data= %.6f', large$res$beta_corr_sp_data-0.2)
)
writeLines(res_lines, con = 'probit_experiment_results.txt')
cat(paste(res_lines, collapse='\n'), '\n')
