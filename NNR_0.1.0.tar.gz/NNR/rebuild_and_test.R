# ============================================================
# COMPREHENSIVE NNR PACKAGE REBUILD AND TEST
# ============================================================
# Run this script in RStudio to rebuild and verify the package

cat("========================================\n")
cat("NNR PACKAGE REBUILD AND VERIFICATION\n")
cat("========================================\n\n")

# Set working directory
setwd("c:/Users/u0167326/OneDrive - KU Leuven/Desktop/PHD Research/NNR/NNR")
cat("Working directory:", getwd(), "\n\n")

# ============================================================
# STEP 1: Clean old build files
# ============================================================
cat("STEP 1: Cleaning old build files...\n")

# Clean compiled files
devtools::clean_dll()

# Remove old .o files
o_files <- list.files("src", pattern = "\\.o$", full.names = TRUE)
if (length(o_files) > 0) {
  file.remove(o_files)
  cat("  Removed", length(o_files), "object files\n")
}

# Remove old DLL
dll_files <- list.files("src", pattern = "\\.(dll|so)$", full.names = TRUE)
if (length(dll_files) > 0) {
  file.remove(dll_files)
  cat("  Removed", length(dll_files), "DLL/SO files\n")
}

cat("  Done cleaning\n\n")

# ============================================================
# STEP 2: Regenerate Rcpp exports (CRITICAL)
# ============================================================
cat("STEP 2: Regenerating Rcpp exports...\n")

# Force regeneration by removing old files
if (file.exists("R/RcppExports.R")) {
  file.remove("R/RcppExports.R")
  cat("  Removed old R/RcppExports.R\n")
}
if (file.exists("src/RcppExports.cpp")) {
  file.remove("src/RcppExports.cpp")
  cat("  Removed old src/RcppExports.cpp\n")
}

# Regenerate
Rcpp::compileAttributes()
cat("  Rcpp exports regenerated\n\n")

# ============================================================
# STEP 3: Document and Install
# ============================================================
cat("STEP 3: Documenting and installing package...\n")

# Document
devtools::document()
cat("  Documentation complete\n")

# Install (CRITICAL - load_all() doesn't register C++ properly)
cat("  Installing package (this compiles C++ code)...\n")
devtools::install(force = TRUE, upgrade = "never")
cat("  Installation complete\n\n")

# ============================================================
# STEP 4: Load fresh copy of package
# ============================================================
cat("STEP 4: Loading installed package...\n")

# Detach if currently loaded
if ("package:NNR" %in% search()) {
  detach("package:NNR", unload = TRUE)
  cat("  Detached old version\n")
}

# Load fresh
library(NNR)
cat("  Package loaded successfully\n\n")

# ============================================================
# STEP 5: Test all C++ functions
# ============================================================
cat("========================================\n")
cat("TESTING ALL FUNCTIONS\n")
cat("========================================\n\n")

all_passed <- TRUE

# Test 1: SVD
cat("Test 1: SVD()... ")
tryCatch({
  A <- matrix(c(1, 2, 3, 4, 5, 6), 2, 3)
  result <- SVD(A)
  stopifnot("U_" %in% names(result) || "U" %in% names(result))
  cat("PASSED\n")
}, error = function(e) {
  cat("FAILED -", e$message, "\n")
  all_passed <<- FALSE
})

# Test 2: SVT
cat("Test 2: SVT()... ")
tryCatch({
  A <- matrix(rnorm(12), 3, 4)
  svd_A <- SVD(A)
  
  # Handle both naming conventions
  U <- if ("U_" %in% names(svd_A)) svd_A$U_ else svd_A$U
  V <- if ("V_" %in% names(svd_A)) svd_A$V_ else svd_A$V
  sigma <- if ("sigma_" %in% names(svd_A)) svd_A$sigma_ else svd_A$sigma
  
  result <- SVT(U, V, sigma, lambda = 0.5)
  stopifnot(is.list(result))
  cat("PASSED\n")
}, error = function(e) {
  cat("FAILED -", e$message, "\n")
  all_passed <<- FALSE
})

# Test 3: Low_rank_appro
cat("Test 3: Low_rank_appro()... ")
tryCatch({
  A <- matrix(rnorm(20), 4, 5)
  result <- Low_rank_appro(A, num_factor = 2)
  stopifnot(is.list(result))
  cat("PASSED\n")
}, error = function(e) {
  cat("FAILED -", e$message, "\n")
  all_passed <<- FALSE
})

# Test 4: Compute_generalized_inverse
cat("Test 4: Compute_generalized_inverse()... ")
tryCatch({
  A <- matrix(c(1, 2, 3, 4, 5, 6, 7, 8, 10), 3, 3)
  result <- Compute_generalized_inverse(A)
  stopifnot(is.matrix(result))
  cat("PASSED\n")
}, error = function(e) {
  cat("FAILED -", e$message, "\n")
  all_passed <<- FALSE
})

# Test 5: Compute_index_with_theta
cat("Test 5: Compute_index_with_theta()... ")
tryCatch({
  X <- list(matrix(rnorm(12), 3, 4), matrix(rnorm(12), 3, 4))
  beta <- c(0.5, 1.0)
  Theta <- matrix(rnorm(12), 3, 4)
  result <- Compute_index_with_theta(X, beta, Theta)
  stopifnot(is.matrix(result))
  cat("PASSED\n")
}, error = function(e) {
  cat("FAILED -", e$message, "\n")
  all_passed <<- FALSE
})

# Test 6: data_frame_to_list
cat("Test 6: data_frame_to_list()... ")
tryCatch({
  N <- 5; T <- 4
  df <- matrix(0, N * T, 5)
  df[, 1] <- rep(1:N, each = T)
  df[, 2] <- rep(1:T, times = N)
  df[, 3] <- rnorm(N * T)
  df[, 4] <- rnorm(N * T)
  df[, 5] <- rnorm(N * T)
  result <- data_frame_to_list(df)
  stopifnot(is.list(result))
  cat("PASSED\n")
}, error = function(e) {
  cat("FAILED -", e$message, "\n")
  all_passed <<- FALSE
})

# Test 7: calculate_tuning_parameter
cat("Test 7: calculate_tuning_parameter()... ")
tryCatch({
  Y <- matrix(rbinom(20, 1, 0.5), 4, 5)
  X <- list(matrix(rnorm(20), 4, 5))
  result <- calculate_tuning_parameter(Y, X, delta = 0.05, func = "logit")
  stopifnot(is.numeric(result))
  cat("PASSED\n")
}, error = function(e) {
  cat("FAILED -", e$message, "\n")
  all_passed <<- FALSE
})

cat("\n")

# ============================================================
# STEP 6: Full integration test
# ============================================================
cat("========================================\n")
cat("INTEGRATION TEST: NNRPanel_estimate\n")
cat("========================================\n\n")

tryCatch({
  set.seed(42)
  
  # Parameters
  N <- 20
  T <- 25
  R <- 2
  beta_true <- c(1.0, 0.5)
  
  cat("Generating test data:\n")
  cat("  N =", N, ", T =", T, ", R =", R, "\n")
  cat("  True beta =", beta_true, "\n\n")
  
  # Generate factors
  L <- matrix(rnorm(N * R, sd = 0.5), N, R)
  F_mat <- matrix(rnorm(T * R, sd = 0.5), T, R)
  Lambda <- L %*% t(F_mat)
  
  # Generate covariates
  X1 <- matrix(rnorm(N * T), N, T)
  X2 <- matrix(rnorm(N * T), N, T)
  
  # Generate outcome
  index <- beta_true[1] * X1 + beta_true[2] * X2 + Lambda
  prob <- 1 / (1 + exp(-index))
  Y <- matrix(rbinom(N * T, 1, as.vector(prob)), N, T)
  
  cat("  Y mean:", round(mean(Y), 3), "\n")
  cat("  Index range:", round(range(index), 2), "\n\n")
  
  # Convert to data_frame format
  data_frame <- matrix(0, N * T, 5)
  data_frame[, 1] <- rep(1:N, each = T)
  data_frame[, 2] <- rep(1:T, times = N)
  data_frame[, 3] <- as.vector(t(Y))
  data_frame[, 4] <- as.vector(t(X1))
  data_frame[, 5] <- as.vector(t(X2))
  
  cat("Running NNRPanel_estimate...\n")
  
  result <- NNRPanel_estimate(
    data_frame = data_frame,
    func = "logit",
    delta = 0.05,
    R_max = 5,
    R_true = R,
    s = 10,
    iter_max = 100,
    tol = 1e-6
  )
  
  cat("\n========================================\n")
  cat("RESULTS\n")
  cat("========================================\n")
  cat("True beta:     ", beta_true, "\n")
  cat("Estimated beta:", round(result$beta_nnr[1:2], 4), "\n")
  cat("True rank:     ", R, "\n")
  cat("Estimated rank:", result$num_factor_est, "\n\n")
  
  # Compute error
  error <- sqrt(sum((result$beta_nnr[1:2] - beta_true)^2))
  cat("Estimation error:", round(error, 4), "\n")
  
  if (error < 1) {
    cat("\n*** INTEGRATION TEST PASSED ***\n")
  } else {
    cat("\n*** WARNING: Large estimation error ***\n")
  }
  
}, error = function(e) {
  cat("\n*** INTEGRATION TEST FAILED ***\n")
  cat("Error:", e$message, "\n")
  all_passed <- FALSE
})

# ============================================================
# Summary
# ============================================================
cat("\n========================================\n")
cat("SUMMARY\n")
cat("========================================\n")

if (all_passed) {
  cat("\n*** ALL TESTS PASSED! Package is working correctly. ***\n\n")
} else {
  cat("\n*** SOME TESTS FAILED. Check the errors above. ***\n\n")
}

cat("To use the package in the future:\n")
cat("  library(NNR)\n")
cat("  result <- NNRPanel_estimate(data_frame, func='logit', R_max=5)\n\n")
