@echo off
cd /d "c:\Users\u0167326\OneDrive - KU Leuven\Desktop\PHD Research\NNR\NNR"
"R" CMD INSTALL -l "C:\Users\u0167326\AppData\Local\R\win-library\4.3" .
pause
