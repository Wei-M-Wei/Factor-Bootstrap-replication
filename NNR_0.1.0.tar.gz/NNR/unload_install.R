if ('NNR' %in% loadedNamespaces()) {
  try(detach('package:NNR', unload=TRUE, character.only=TRUE), silent=TRUE)
  try(unloadNamespace('NNR'), silent=TRUE)
}
# Run R CMD INSTALL from this directory
setwd("c:/Users/u0167326/OneDrive - KU Leuven/Desktop/PHD Research/NNR/NNR")
system('R CMD INSTALL -l "C:/Users/u0167326/AppData/Local/R/win-library/4.3" .')
