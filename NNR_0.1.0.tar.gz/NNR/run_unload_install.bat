@echo off
"Rscript" "c:\Users\u0167326\OneDrive - KU Leuven\Desktop\PHD Research\NNR\NNR\unload_install.R"
pause
