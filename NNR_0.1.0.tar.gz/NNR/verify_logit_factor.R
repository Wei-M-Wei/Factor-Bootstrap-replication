# ============================================================
# Verification Script for NNR Package - Logit Factor Model
# ============================================================
# This script tests the correctness of NNRPanel_estimate by:
# 1. Generating data from a known logit factor model
# 2. Estimating with NNRPanel_estimate
# 3. Comparing estimates to true values
# ============================================================

library(NNR)
set.seed(12345)

# ============================================================
# TRUE PARAMETERS
# ============================================================
N <- 100          # Number of individuals
T <- 50           # Number of time periods
R <- 2            # Number of latent factors
beta_true <- c(1.0, -0.5)  # True regression coefficients

cat("============================================================\n")
cat("LOGIT FACTOR MODEL - VERIFICATION TEST\n")
cat("============================================================\n")
cat("True Parameters:\n")
cat("  N =", N, ", T =", T, "\n")
cat("  Number of factors R =", R, "\n")
cat("  True beta =", beta_true, "\n")
cat("============================================================\n\n")

# ============================================================
# STEP 1: GENERATE DATA FROM LOGIT FACTOR MODEL
# ============================================================
# Model: P(Y_it = 1 | X_it, alpha_it) = 1 / (1 + exp(-eta_it))
# where: eta_it = X_it' * beta + alpha_it
#        alpha_it = lambda_i' * f_t (interactive fixed effects)

cat("Generating data...\n")

# Generate factor loadings (N x R) and factors (T x R)
# Scale factor loadings to control signal strength
lambda <- matrix(rnorm(N * R, mean = 0, sd = 1), N, R)
f <- matrix(rnorm(T * R, mean = 0, sd = 1), T, R)

# Interactive fixed effects: alpha = lambda * f'
# This is an N x T matrix
alpha <- lambda %*% t(f)

cat("  Factor loading range: [", round(min(lambda), 2), ",", round(max(lambda), 2), "]\n")
cat("  Factor range: [", round(min(f), 2), ",", round(max(f), 2), "]\n")
cat("  Alpha (fixed effects) range: [", round(min(alpha), 2), ",", round(max(alpha), 2), "]\n")

# Generate covariates X1 and X2
# Add some correlation with factors to make it realistic
X1 <- matrix(rnorm(N * T), N, T) + 0.3 * lambda[, 1] %*% t(f[, 1])
X2 <- matrix(rnorm(N * T), N, T) + 0.2 * lambda[, 2] %*% t(f[, 2])

cat("  X1 range: [", round(min(X1), 2), ",", round(max(X1), 2), "]\n")
cat("  X2 range: [", round(min(X2), 2), ",", round(max(X2), 2), "]\n")

# Linear index: eta = X1*beta1 + X2*beta2 + alpha
eta <- beta_true[1] * X1 + beta_true[2] * X2 + alpha

cat("  Linear index (eta) range: [", round(min(eta), 2), ",", round(max(eta), 2), "]\n")

# Generate Y from logit model
# P(Y=1) = 1/(1+exp(-eta))
prob <- 1 / (1 + exp(-eta))
Y <- matrix(rbinom(N * T, size = 1, prob = prob), N, T)

cat("  Y mean (proportion of 1s):", round(mean(Y), 3), "\n")
cat("  Probability range: [", round(min(prob), 3), ",", round(max(prob), 3), "]\n\n")

# ============================================================
# STEP 2: CREATE DATA FRAME FOR NNRPanel_estimate
# ============================================================
# Format: [ID, Time, Y, X1, X2, ...]

cat("Creating data frame...\n")

data_frame <- matrix(0, N * T, 5)
idx <- 1
for (i in 1:N) {
  for (t in 1:T) {
    data_frame[idx, 1] <- i         # ID
    data_frame[idx, 2] <- t         # Time
    data_frame[idx, 3] <- Y[i, t]   # Y
    data_frame[idx, 4] <- X1[i, t]  # X1
    data_frame[idx, 5] <- X2[i, t]  # X2
    idx <- idx + 1
  }
}

cat("  Data frame dimensions:", nrow(data_frame), "x", ncol(data_frame), "\n")
cat("  Sample: first 5 rows:\n")
print(head(data_frame, 5))
cat("\n")

# ============================================================
# STEP 3: RUN NNRPanel_estimate
# ============================================================

cat("Running NNRPanel_estimate with R_true =", R, "...\n")
cat("This may take a minute...\n\n")

result <- NNRPanel_estimate(
  data_frame = data_frame,
  func = "logit",
  delta = 0.05,
  R_max = 5,
  R_true = R,      # Pass the true number of factors
  s = 10,
  iter_max = 10000,
  tol = 1e-8
)

# ============================================================
# STEP 4: DISPLAY RESULTS
# ============================================================

cat("\n============================================================\n")
cat("ESTIMATION RESULTS\n")
cat("============================================================\n\n")

cat("1. NNR (Nuclear Norm Regularized) Estimator:\n")
cat("   beta_nnr =", round(result$beta_nnr, 4), "\n")
cat("   Bias =", round(result$beta_nnr - beta_true, 4), "\n\n")

cat("2. Data-driven factor selection:\n")
cat("   Estimated number of factors =", result$num_factor_est, "\n\n")

cat("3. MLE with R_true =", R, "(known factors):\n")
cat("   beta_fe =", round(result$beta_fe, 4), "\n")
cat("   Bias =", round(result$beta_fe - beta_true, 4), "\n\n")

cat("4. Analytical Bias Correction (R_true):\n")
cat("   beta_corr =", round(result$beta_corr, 4), "\n")
cat("   Bias =", round(result$beta_corr - beta_true, 4), "\n\n")

cat("5. Split-Panel Jackknife Bias Correction (R_true):\n")
cat("   beta_corr_sp =", round(result$beta_corr_sp, 4), "\n")
cat("   Bias =", round(result$beta_corr_sp - beta_true, 4), "\n\n")

cat("6. Standard Errors (R_true):\n")
cat("   std_beta_corr =", round(result$std_beta_corr, 4), "\n\n")

cat("7. 95% Confidence Intervals:\n")
z_alpha <- qnorm(0.975)
for (j in 1:length(beta_true)) {
  ci_low <- result$beta_corr[j] - z_alpha * result$std_beta_corr[j]
  ci_high <- result$beta_corr[j] + z_alpha * result$std_beta_corr[j]
  covers <- (beta_true[j] >= ci_low) & (beta_true[j] <= ci_high)
  cat("   beta", j, ": [", round(ci_low, 4), ",", round(ci_high, 4), "]",
      "| True:", beta_true[j], "| Covers:", covers, "\n")
}

cat("\n============================================================\n")
cat("SUMMARY TABLE\n")
cat("============================================================\n")
cat(sprintf("%-20s %10s %10s %10s\n", "Method", "beta1", "beta2", "RMSE"))
cat("------------------------------------------------------------\n")
cat(sprintf("%-20s %10.4f %10.4f %10s\n", "True", beta_true[1], beta_true[2], "-"))

rmse_nnr <- sqrt(mean((result$beta_nnr - beta_true)^2))
cat(sprintf("%-20s %10.4f %10.4f %10.4f\n", "NNR", result$beta_nnr[1], result$beta_nnr[2], rmse_nnr))

rmse_fe <- sqrt(mean((result$beta_fe - beta_true)^2))
cat(sprintf("%-20s %10.4f %10.4f %10.4f\n", "MLE (R_true)", result$beta_fe[1], result$beta_fe[2], rmse_fe))

rmse_corr <- sqrt(mean((result$beta_corr - beta_true)^2))
cat(sprintf("%-20s %10.4f %10.4f %10.4f\n", "Analytical BC", result$beta_corr[1], result$beta_corr[2], rmse_corr))

rmse_sp <- sqrt(mean((result$beta_corr_sp - beta_true)^2))
cat(sprintf("%-20s %10.4f %10.4f %10.4f\n", "Split-Panel JK", result$beta_corr_sp[1], result$beta_corr_sp[2], rmse_sp))

cat("============================================================\n")
cat("\nExpected behavior:\n")
cat("- MLE (beta_fe) may have incidental parameter bias\n")
cat("- Bias-corrected estimates should be closer to true values\n")
cat("- Split-panel jackknife is often more robust than analytical BC\n")
cat("- With N=100, T=50, bias should be moderate\n")
cat("============================================================\n")
