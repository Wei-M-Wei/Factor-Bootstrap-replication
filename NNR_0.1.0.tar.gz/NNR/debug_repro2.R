# debug_repro2.R - try smaller iter_max to isolate crash
library(magrittr)
if (!requireNamespace("NNR", quietly = TRUE)) stop("Install package 'NNR' first")
library(NNR)

run_once <- function(iter_lim){
  dat <- NNR:::gen_data_probit(N = 30, T = 20, num_factor = 1, num_Z = 1, beta = c(0.2))
  df <- NNR:::list_to_data_frame(dat)
  cat("Running with iter_max=", iter_lim, "\n")
  res <- NNR::NNRPanel_estimate(
    data_frame = df,
    func       = "probit",
    R_max      = 1,
    R_true     = 1,
    R_true_only = TRUE,
    s = 10,
    iter_max = iter_lim,
    tol = 1e-6
  )
  return(res)
}

for(it in c(20,50,100,200)){
  cat("--- iter_max =", it, "---\n")
  try({
    res <- run_once(it)
    cat("Completed for iter_max=", it, "\n")
  }, silent=FALSE)
}
cat("done\n")
