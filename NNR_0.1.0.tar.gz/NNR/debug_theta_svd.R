# Debug: Check NNR Theta singular values

library(NNR)
set.seed(42)

N <- 30
T <- 20
R <- 1
beta_true <- 1.0

lambda <- matrix(rnorm(N * R, sd = 0.5), N, R)
f <- matrix(rnorm(T * R, sd = 0.5), T, R)
alpha <- lambda %*% t(f)
X1 <- matrix(rnorm(N * T), N, T)
eta <- beta_true * X1 + alpha
prob <- 1 / (1 + exp(-eta))
Y <- matrix(rbinom(N * T, 1, prob), N, T)

# Convert to data frame
df <- cbind(rep(1:N, each = T), rep(1:T, N), as.vector(t(Y)), as.vector(t(X1)))
data_list <- data_frame_to_list(df)

cat("=== True alpha ===\n")
svd_true <- SVD(alpha)
cat("True alpha singular values:", head(svd_true$sigma_, 5), "\n\n")

cat("=== Using tuning parameter calculation ===\n")
phi <- calculate_tuning_parameter(df, "logit", 0.05, R_max = 3)
cat("Calculated phi:", phi, "\n\n")

# Test with different phi values
for (test_phi in c(0.1, 0.5, 1, 2, 5, phi)) {
  cat("=== phi =", test_phi, "===\n")
  
  # Run NNRPanel with this phi
  result <- tryCatch({
    NNRPanel_estimate(
      data_frame = df,
      phi = test_phi,
      func = "logit",
      delta = 0.05,
      R_max = 3,
      R_true = R
    )
  }, error = function(e) {
    cat("Error:", e$message, "\n")
    NULL
  })
  
  if (!is.null(result)) {
    cat("  num_factor_est:", result$num_factor_est, "\n")
    cat("  beta_fe:", round(result$beta_fe, 4), "\n")
    cat("  beta_corr:", round(result$beta_corr, 4), "\n")
    cat("  B+D effect:", round(result$beta_corr - result$beta_fe, 4), "\n\n")
  }
}
