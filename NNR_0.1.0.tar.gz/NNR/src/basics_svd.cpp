#include "basics.h"
#include <cmath>

// [[Rcpp::export]]
List SVD(NumericMatrix & A){
    Map<MatrixXd> A_(as<Map<MatrixXd>> (A));
    
    // Clean small values
    for(int j=0; j!=A_.cols(); j++){
        for(int i=0; i!=A_.rows(); i++){
            if(abs(A(i,j))<=1e-15){
                A(i,j) = 0;
            }
        }
    }
    
    // Add diagonal regularization
    for(int i = 0; i < A_.rows() && i < A_.cols(); i++){
        A_(i, i) = A_(i, i) + 1e-10;
    }
    
    // Use Jacobi SVD only
    JacobiSVD<MatrixXd> svd(A_, ComputeThinV | ComputeThinU);
    
    return List::create(Named("U_") = wrap(svd.matrixU()),
                        Named("V_") = wrap(svd.matrixV()),
                        Named("sigma_") = wrap(svd.singularValues()));
}
