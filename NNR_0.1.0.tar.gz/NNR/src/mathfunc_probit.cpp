#include "basics.h"
#include "mathfunc_probit.h"

// [[Rcpp::export]]

NumericMatrix Compute_logl_probit_with_theta(const List & X,  const NumericMatrix & Y,
                                             const NumericVector & beta, const NumericMatrix & Theta ){

    const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));

    double epsilon = 1e-10;

    NumericMatrix logl_est = Compute_index_with_theta(X, beta, Theta);
    Map<MatrixXd> logl_est_ (as <Map<MatrixXd>> (logl_est));

    for (int i = 0; i < logl_est_.rows(); i++) {
        for (int j = 0; j < logl_est_.cols(); j++) {
            logl_est_(i, j) = R::pnorm5(logl_est_(i, j), 0.0, 1.0, 1, 0);
        }
    }

    logl_est_ = Y_.array() * (logl_est_.array() + epsilon).log()
        + (1 - Y_.array() ) * (1 - logl_est_.array() + epsilon).log();
    return wrap(logl_est_);
}

// [[Rcpp::export]]

NumericMatrix Compute_logl_probit_with_theta_FE(const List & X,  const NumericMatrix & Y,
                                               const NumericVector & beta,
                                               const NumericVector & fe_N, const NumericVector & fe_T,
                                               const NumericMatrix & Theta ){

    const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));

    double epsilon = 1e-10;

    NumericMatrix logl_est = Compute_index_with_theta_FE(X, beta, fe_N, fe_T, Theta);
    Map<MatrixXd> logl_est_ (as <Map<MatrixXd>> (logl_est));

    for (int i = 0; i < logl_est_.rows(); i++) {
        for (int j = 0; j < logl_est_.cols(); j++) {
            logl_est_(i, j) = R::pnorm5(logl_est_(i, j), 0.0, 1.0, 1, 0);
        }
    }

    logl_est_ = Y_.array() * (logl_est_.array() + epsilon).log()
        + (1 - Y_.array() ) * (1 - logl_est_.array() + epsilon).log();

    return wrap(logl_est_);
}

// [[Rcpp::export]]

NumericMatrix Compute_logl_probit_with_LR(const List & X,  const NumericMatrix & Y,
                                          const NumericVector & beta,
                                          const NumericMatrix & L, const NumericMatrix & R ){

    const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));
    double epsilon = 1e-10;

    NumericMatrix logl_est = Compute_index_with_LR(X, beta, L, R);
    Map<MatrixXd> logl_est_ (as <Map<MatrixXd>> (logl_est));

    for (int i = 0; i < logl_est_.rows(); i++) {
        for (int j = 0; j < logl_est_.cols(); j++) {
            logl_est_(i, j) = R::pnorm5(logl_est_(i, j), 0.0, 1.0, 1, 0);
        }
    }

    logl_est_ = Y_.array() * (logl_est_.array() + epsilon).log()
        + (1 - Y_.array() ) * (1 - logl_est_.array() + epsilon).log();

    return wrap(logl_est_);
}


// [[Rcpp::export]]

NumericMatrix Compute_logl_probit_with_LR_FE(const List & X,  const NumericMatrix & Y,
                                            const NumericVector & beta,
                                            const NumericVector & fe_N, const NumericVector & fe_T,
                                            const NumericMatrix & L, const NumericMatrix & R ){

    const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));
    double epsilon = 1e-10;

    NumericMatrix logl_est = Compute_index_with_LR_FE(X, beta,fe_N, fe_T, L, R);
    Map<MatrixXd> logl_est_ (as <Map<MatrixXd>> (logl_est));

    for (int i = 0; i < logl_est_.rows(); i++) {
        for (int j = 0; j < logl_est_.cols(); j++) {
            logl_est_(i, j) = R::pnorm5(logl_est_(i, j), 0.0, 1.0, 1, 0);
        }
    }

    logl_est_ = Y_.array() * (logl_est_.array() + epsilon).log()
        + (1 - Y_.array() ) * (1 - logl_est_.array() + epsilon).log();

    return wrap(logl_est_);
}

// [[Rcpp::export]]

List Compute_score_probit_with_theta(const List & X, const NumericMatrix & Y,
                                    const NumericVector & beta, const NumericMatrix & Theta){
    const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));
    const int N = Y_.rows();
    const int T = Y_.cols();
    double epsilon = 1e-10;


    NumericMatrix score = Compute_index_with_theta(X, beta, Theta);
    Map<MatrixXd> score_ (as <Map<MatrixXd>> (score));
    NumericVector score_beta = wrap(VectorXd::Constant(X.length(), 0.0));

    MatrixXd pdf_ = MatrixXd::Constant(N, T, 0);


    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            pdf_(i, j) = R::dnorm4(score_(i, j), 0.0, 1.0, 0);
        }
    }
    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            score_(i, j) = R::pnorm5(score_(i, j), 0.0, 1.0, 1, 0);
        }
    }

    score_ = (score_.array() * (1.0 - score_.array()) + epsilon ).inverse() * (Y_.array() - score_.array() );
    score_ = score_.array() * pdf_.array();

    for(int i=0; i!=X.length(); i++){
        const Map<MatrixXd> X_ (as <Map<MatrixXd>> (X[i]));
        score_beta(i) = (score_.array() * X_.array()).sum();
    }
    return List::create(Named("score_beta") = score_beta,
                        Named("score_theta") =  score_);
}

// [[Rcpp::export]]

List Compute_score_probit_with_theta_FE(const List & X, const NumericMatrix & Y,
                                       const NumericVector & beta,
                                       const NumericVector & fe_N, const NumericVector & fe_T,
                                       const NumericMatrix & Theta){
    const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));
    const int N = Y_.rows();
    const int T = Y_.cols();
    double epsilon = 1e-10;

    NumericMatrix score = Compute_index_with_theta_FE(X, beta, fe_N, fe_T, Theta);
    Map<MatrixXd> score_ (as <Map<MatrixXd>> (score));
    NumericVector score_beta = wrap(VectorXd::Constant(X.length(), 0.0));

    MatrixXd pdf_ = MatrixXd::Constant(N, T, 0);


    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            pdf_(i, j) = R::dnorm4(score_(i, j), 0.0, 1.0, 0);
        }
    }
    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            score_(i, j) = R::pnorm5(score_(i, j), 0.0, 1.0, 1, 0);
        }
    }

    score_ = (score_.array() * (1.0 - score_.array()) + epsilon ).inverse() * (Y_.array() - score_.array() );
    score_ = score_.array() * pdf_.array();

    for(int i=0; i!=X.length(); i++){
        const Map<MatrixXd> X_ (as <Map<MatrixXd>> (X[i]));
        score_beta(i) = (score_.array() * X_.array()).sum();
    }

    return List::create(Named("score_beta") = score_beta,
                        Named("score_theta") =  score_);
}

// [[Rcpp::export]]

List Compute_score_probit_with_LR(const List & X, const NumericMatrix & Y,
                                 const NumericVector & beta,
                                 const NumericMatrix & L, const NumericMatrix & R){

    const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));
    const Map<MatrixXd> L_ (as <Map<MatrixXd>> (L));
    const Map<MatrixXd> R_ (as <Map<MatrixXd>> (R));
    const int N = Y_.rows();
    const int T = Y_.cols();
    double epsilon = 1e-10;


    NumericMatrix score = Compute_index_with_LR(X, beta, L, R);
    Map<MatrixXd> score_ (as <Map<MatrixXd>> (score));
    NumericVector score_beta = wrap(VectorXd::Constant(X.length(), 0.0));

    MatrixXd pdf_ = MatrixXd::Constant(N, T, 0);

    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            pdf_(i, j) = R::dnorm4(score_(i, j), 0.0, 1.0, 0);
        }
    }
    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            score_(i, j) = R::pnorm5(score_(i, j), 0.0, 1.0, 1, 0);
        }
    }

    score_ = (score_.array() * (1.0 - score_.array()) + epsilon ).inverse() * (Y_.array() - score_.array() );
    score_ = score_.array() * pdf_.array();

    for(int i=0; i!=X.length(); i++){
        const Map<MatrixXd> X_ (as <Map<MatrixXd>> (X[i]));
        score_beta(i) = (score_.array() * X_.array()).sum();
    }
    MatrixXd score_L_ = score_ * R_;
    MatrixXd score_R_ = score_.transpose() * L_;

    return List::create(Named("score_beta") = score_beta,
                        Named("score_L") =  wrap(score_L_),
                        Named("score_R") =  wrap(score_R_));
}


// [[Rcpp::export]]

List Compute_score_probit_with_LR_FE(const List & X, const NumericMatrix & Y,
                                    const NumericVector & beta,
                                    const NumericVector & fe_N, const NumericVector & fe_T,
                                    const NumericMatrix & L, const NumericMatrix & R){

    const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));
    const Map<MatrixXd> L_ (as <Map<MatrixXd>> (L));
    const Map<MatrixXd> R_ (as <Map<MatrixXd>> (R));
    const int N = Y_.rows();
    const int T = Y_.cols();
    double epsilon = 1e-10;


    NumericMatrix score = Compute_index_with_LR_FE(X, beta, fe_N, fe_T, L, R);
    Map<MatrixXd> score_ (as <Map<MatrixXd>> (score));
    NumericVector score_beta = wrap(VectorXd::Constant(X.length(), 0.0));

    MatrixXd pdf_ = MatrixXd::Constant(N, T, 0);

    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            pdf_(i, j) = R::dnorm4(score_(i, j), 0.0, 1.0, 0);
        }
    }
    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            score_(i, j) = R::pnorm5(score_(i, j), 0.0, 1.0, 1, 0);
        }
    }

    score_ = (score_.array() * (1.0 - score_.array()) + epsilon ).inverse() * (Y_.array() - score_.array() );
    score_ = score_.array() * pdf_.array();

    for(int i=0; i!=X.length(); i++){
        const Map<MatrixXd> X_ (as <Map<MatrixXd>> (X[i]));
        score_beta(i) = (score_.array() * X_.array()).sum();
    }
    MatrixXd score_L_ = score_ * R_;
    MatrixXd score_R_ = score_.transpose() * L_;

    return List::create(Named("score_beta") = score_beta,
                        Named("score_L") =  wrap(score_L_),
                        Named("score_R") =  wrap(score_R_));
}


// [[Rcpp::export]]

double Compute_obj_probit_with_theta(const List & X,  const NumericMatrix & Y,
                                    const NumericVector & beta, const NumericMatrix & Theta,
                                    const double sigma_sum, const double phi){
    NumericMatrix logl_probit = Compute_logl_probit_with_theta( X,  Y, beta, Theta );
    Map<MatrixXd> logl_probit_ (as <Map<MatrixXd>> (logl_probit));
    double loss = logl_probit_.sum();
    double obj  = -loss + phi * sigma_sum;
    return obj;
}


// [[Rcpp::export]]

double Compute_obj_probit_with_theta_FE(const List & X,  const NumericMatrix & Y,
                                       const NumericVector & beta,
                                       const NumericVector & fe_N, const NumericVector & fe_T,
                                       const NumericMatrix & Theta,
                                       const double sigma_sum, const double phi){
    NumericMatrix logl_probit = Compute_logl_probit_with_theta_FE( X,  Y, beta, fe_N, fe_T, Theta );
    Map<MatrixXd> logl_probit_ (as <Map<MatrixXd>> (logl_probit));
    double loss = logl_probit_.sum();
    double obj  = -loss + phi * sigma_sum;
    return obj;
}


// [[Rcpp::export]]

double Compute_obj_probit_with_LR(const List & X,  const NumericMatrix & Y,
                                 const NumericVector & beta,
                                 const NumericMatrix & L, const NumericMatrix & R){
    NumericMatrix logl_probit = Compute_logl_probit_with_LR( X,  Y, beta, L, R );
    Map<MatrixXd> logl_probit_ (as <Map<MatrixXd>> (logl_probit));
    double loss = logl_probit_.sum();
    double obj  = -loss;
    return obj;
}


// [[Rcpp::export]]

double Compute_obj_probit_with_LR_FE(const List & X,  const NumericMatrix & Y,
                                    const NumericVector & beta,
                                    const NumericVector & fe_N, const NumericVector & fe_T,
                                    const NumericMatrix & L, const NumericMatrix & R){
    NumericMatrix logl_probit = Compute_logl_probit_with_LR_FE( X,  Y, beta,fe_N, fe_T, L, R );
    Map<MatrixXd> logl_probit_ (as <Map<MatrixXd>> (logl_probit));
    double loss = logl_probit_.sum();
    double obj  = -loss;
    return obj;
}


// [[Rcpp::export]]

NumericMatrix Compute_first_order_probit_with_LR(const List & X, const NumericMatrix & Y,
                                                const NumericVector & beta,
                                                const NumericMatrix & L, const NumericMatrix & R){
    const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));
    const int N = Y_.rows();
    const int T = Y_.cols();
    double epsilon = 1e-10;

    NumericMatrix first_score = Compute_index_with_LR(X, beta, L, R);
    Map<MatrixXd> first_score_ (as <Map<MatrixXd>> (first_score));

    MatrixXd pdf_ = MatrixXd::Constant(N, T, 0);

    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            pdf_(i, j) = R::dnorm4(first_score_(i, j), 0.0, 1.0, 0);
        }
    }
    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            first_score_(i, j) = R::pnorm5(first_score_(i, j), 0.0, 1.0, 1, 0);
        }
    }

    first_score_ = (first_score_.array() * (1.0 - first_score_.array()) + epsilon ).inverse() * (Y_.array() - first_score_.array() );
    first_score_ = first_score_.array() * pdf_.array();

    return wrap(first_score_);
}


// [[Rcpp::export]]

NumericMatrix Compute_second_order_probit_with_LR(const List & X, const NumericMatrix & Y,
                                                  const NumericVector & beta,
                                                  const NumericMatrix & L, const NumericMatrix & R){
    const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));
    NumericMatrix index = Compute_index_with_LR(X, beta, L, R);
    Map<MatrixXd> index_ (as <Map<MatrixXd>> (index));
    int N = Y_.rows();
    int T = Y_.cols();

    MatrixXd second_score_ = MatrixXd::Constant(N, T, 0);
    MatrixXd cdf_ = MatrixXd::Constant(N, T, 0);
    MatrixXd pdf_ = MatrixXd::Constant(N, T, 0);

    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            pdf_(i, j) = R::dnorm4(index_(i, j), 0.0, 1.0, 0);
        }
    }
    for (int i = 0; i!=N; i++) {
        for (int j = 0; j!=T; j++) {
            cdf_(i, j) = R::pnorm5(index_(i, j), 0.0, 1.0, 1, 0);
        }
    }


    double epsilon = 1e-10;

    second_score_ = index_.array() * pdf_.array() * (Y_.array() - cdf_.array()) * (cdf_.array() * (1-cdf_.array()) + epsilon).inverse();
    second_score_ = second_score_.array() + pdf_.array() *pdf_.array() * (cdf_.array() * cdf_.array() + Y_.array()* (1 - 2* cdf_.array())) * ( cdf_.array() * cdf_.array() * (1 - cdf_.array()) * (1- cdf_.array()) + epsilon).inverse();
    second_score_ = -second_score_.array();
    return wrap(second_score_);
}


// [[Rcpp::export]]
NumericMatrix Compute_third_order_probit_with_LR(const List & X, const NumericMatrix & Y, const NumericVector & beta, const NumericMatrix & L, const NumericMatrix & R){
    const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));
    NumericMatrix third_score = Compute_index_with_LR(X, beta, L, R);
    Map<MatrixXd> third_score_ (as <Map<MatrixXd>> (third_score));

    double epsilon = 1e-10;
    int N = third_score_.rows();
    int T = third_score_.cols();
    int n = N * T;

    Map<const VectorXd> z_vec(third_score_.data(), n);
    Map<const VectorXd> y_vec(Y_.data(), n);

    const double inv_sqrt2pi = 1.0 / std::sqrt(2.0 * M_PI);
    VectorXd Phi(n);
    for(int i=0;i<n;i++){
        double zv = z_vec(i);
        double pv = R::pnorm(zv, 0.0, 1.0, 1, 0);
        if(pv < epsilon) pv = epsilon;
        if(pv > 1.0 - epsilon) pv = 1.0 - epsilon;
        Phi(i) = pv;
    }

    VectorXd phi = inv_sqrt2pi * (-0.5 * z_vec.array().square()).exp().matrix();

    VectorXd v = (Phi.array() * (1.0 - Phi.array())).matrix();
    for(int i=0;i<n;i++) if(v(i) <= epsilon) v(i) = epsilon;
    // Implement user-provided third-derivative formula:
    // d3 = (eta^2-1)*phi*(y-Phi)/v
    //      + 3*eta*phi^2*(y-2yPhi+Phi^2)/v^2
    //      - phi^3 * {2(Phi-y)Phi(1-Phi) - 2(1-2Phi)*(y-2yPhi+Phi^2)} / v^3
    VectorXd term(n);
    for(int i=0;i<n;i++){
        double eta = z_vec(i);
        double y = y_vec(i);
        double Phi_eta = Phi(i);
        double phi_eta = phi(i);
        double v_eta = v(i);
        double diff = y - Phi_eta;

        double term1 = (eta * eta - 1.0) * phi_eta * diff / v_eta;

        double inner2 = y - 2.0 * y * Phi_eta + Phi_eta * Phi_eta; // y - 2yPhi + Phi^2
        double denom2 = v_eta * v_eta;
        double term2 = 3.0 * eta * phi_eta * phi_eta * inner2 / denom2;

        double inner3 = 2.0 * (Phi_eta - y) * Phi_eta * (1.0 - Phi_eta)
                      - 2.0 * (1.0 - 2.0 * Phi_eta) * inner2;
        double denom3 = denom2 * v_eta;
        double term3 = - (phi_eta * phi_eta * phi_eta) * inner3 / denom3;

        term(i) = (term1 + term2 + term3);
    }

    Map<MatrixXd> term_mat(term.data(), N, T);
    third_score_ = term_mat;
    return wrap(third_score_);
}

// NumericMatrix Compute_third_order_probit_with_LR(const List & X, const NumericMatrix & Y,
//                                                  const NumericVector & beta,
//                                                  const NumericMatrix & L, const NumericMatrix & R){
//     const Map<MatrixXd> Y_ (as <Map<MatrixXd>> (Y));
//     NumericMatrix index = Compute_index_with_LR(X, beta, L, R);
//     Map<MatrixXd> index_ (as <Map<MatrixXd>> (index));
//     int N = Y_.rows();
//     int T = Y_.cols();

//     MatrixXd third_score_ = MatrixXd::Constant(N, T, 0);
//     MatrixXd cdf_ = MatrixXd::Constant(N, T, 0);
//     MatrixXd pdf_ = MatrixXd::Constant(N, T, 0);

//     for (int i = 0; i!=N; i++) {
//         for (int j = 0; j!=T; j++) {
//             pdf_(i, j) = R::dnorm4(index_(i, j), 0.0, 1.0, 0);
//         }
//     }
//     for (int i = 0; i!=N; i++) {
//         for (int j = 0; j!=T; j++) {
//             cdf_(i, j) = R::pnorm5(index_(i, j), 0.0, 1.0, 1, 0);
//         }
//     }

//     double epsilon = 1e-10;

//     third_score_ = (index_.array() * index_.array() - 1).array() * pdf_.array()
//         * (Y_.array() * (cdf_.array() + epsilon).inverse() - (1 - Y_.array()).array() * (1 - cdf_.array() + epsilon).inverse());
//     third_score_ = third_score_.array() + 3.0 * index_.array() * pdf_.array() * pdf_.array()
//         * (Y_.array() *  (cdf_.array() * cdf_.array() + epsilon).inverse() + (1 - Y_.array()).array() * ((1 - cdf_.array()) * (1 - cdf_.array())  + epsilon).inverse());
//     third_score_ = third_score_.array() + 2.0 *  pdf_.array() * pdf_.array() * pdf_.array()
//         * (Y_.array() *  (cdf_.array() * cdf_.array()  * cdf_.array() + epsilon).inverse() - (1 - Y_.array()).array() * ((1 - cdf_.array()) * (1 - cdf_.array()) * (1 - cdf_.array())  + epsilon).inverse());
//     third_score_ = 1.0 * third_score_.array();
//     return wrap(third_score_);
// }

// [[Rcpp::export]]
NumericMatrix Sim_dynamic_probit(const List Z,
                                const double beta_W, const NumericVector & beta_Z,
                                const NumericMatrix & Theta){
    Map<MatrixXd> Theta_ (as <Map<MatrixXd>> (Theta));
    int N = Theta_.rows();
    int T = Theta_.cols();

    NumericMatrix index = Compute_index_with_theta(Z, beta_Z, Theta);
    Map<MatrixXd> index_ (as <Map<MatrixXd>> (index));

    MatrixXd W_ = MatrixXd::Constant(N, T, 0.0);

    for(int i = 0; i!=N; i++){
        double p = R::pnorm(index_(i,0), 0.0, 1.0, 1, 0);
        double error = R::runif(0.0, 1.0);
        W_(i,0) = (error <= p) ? 1 : 0;
        for(int t = 1; t!=T; t++){
            double z = beta_W * W_(i, t-1) +  index_(i, t);
            double p = R::pnorm(z, 0.0, 1.0, 1, 0);
            double error = R::runif(0.0, 1.0);
            if (error<= p){
                W_(i, t) = 1;
            }
            else{
                W_(i, t) = 0;
            }
        }
    }
    return wrap(W_);
}
