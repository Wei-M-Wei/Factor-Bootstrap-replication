#include "basics.h"

// [[Rcpp::export]]
NumericMatrix Compute_index_with_theta(const List & X, const NumericVector & beta, 
                                       const NumericMatrix & Theta ){
    
    const Map<MatrixXd> Theta_ (as <Map<MatrixXd>> (Theta));
    
    MatrixXd index_est_ = Theta_;
    for(int i=0; i!=X.length() ; i++){
        const Map<MatrixXd> X_ (as <Map<MatrixXd>> (X[i]));
        index_est_ = index_est_ + beta[i] * X_;
    }
    return wrap(index_est_);
}

// [[Rcpp::export]]
NumericMatrix Compute_index_with_theta_FE(const List & X, const NumericVector & beta, 
                                          const NumericVector & fe_N, const NumericVector & fe_T,
                                          const NumericMatrix & Theta ){
    
    const Map<MatrixXd> Theta_ (as <Map<MatrixXd>> (Theta));
    const Map<VectorXd> fe_N_ (as <Map<VectorXd>> (fe_N));
    const Map<VectorXd> fe_T_ (as <Map<VectorXd>> (fe_T));
    
    int N = Theta_.rows();
    int T = Theta_.cols();
    
    MatrixXd index_est_ = Theta_;
    for(int i=0; i!=X.length() ; i++){
        const Map<MatrixXd> X_ (as <Map<MatrixXd>> (X[i]));
        index_est_ = index_est_ + beta[i] * X_;
    }
    index_est_ = index_est_ + fe_N_ * MatrixXd::Constant(1, T, 1);
    index_est_ = index_est_ + MatrixXd::Constant(N, 1, 1) * fe_T_.transpose();
    
    return wrap(index_est_);
}


// [[Rcpp::export]]
NumericMatrix Compute_index_with_LR(const List & X, const NumericVector & beta, 
                                    const NumericMatrix & L,  const NumericMatrix & R){
    
    const Map<MatrixXd> L_ (as <Map<MatrixXd>> (L));
    const Map<MatrixXd> R_ (as <Map<MatrixXd>> (R));
    
    MatrixXd index_est_ = L_ * R_.transpose();
    for(int i=0; i!=X.length() ; i++){
        const Map<MatrixXd> X_ (as <Map<MatrixXd>> (X[i]));
        index_est_ = index_est_ + beta[i] * X_;
    }
    return wrap(index_est_);
}


// [[Rcpp::export]]
NumericMatrix Compute_index_with_LR_FE(const List & X, const NumericVector & beta, 
                                       const NumericVector & fe_N, const NumericVector & fe_T,
                                       const NumericMatrix & L,  const NumericMatrix & R){
    
    const Map<MatrixXd> L_ (as <Map<MatrixXd>> (L));
    const Map<MatrixXd> R_ (as <Map<MatrixXd>> (R));
    const Map<VectorXd> fe_N_ (as <Map<VectorXd>> (fe_N));
    const Map<VectorXd> fe_T_ (as <Map<VectorXd>> (fe_T));
    
    int N = L_.rows();
    int T = R_.rows();
    
    MatrixXd index_est_ = L_ * R_.transpose();
    for(int i=0; i!=X.length() ; i++){
        const Map<MatrixXd> X_ (as <Map<MatrixXd>> (X[i]));
        index_est_ = index_est_ + beta[i] * X_;
    }
    index_est_ = index_est_ + fe_N_ * MatrixXd::Constant(1, T, 1);
    index_est_ = index_est_ + MatrixXd::Constant(N, 1, 1) * fe_T_.transpose();
    
    return wrap(index_est_);
}


// [[Rcpp::export]]
NumericMatrix Convert_numeric_matrix_to_vector(const NumericMatrix & A){
    const Map<MatrixXd> A_ (as <Map<MatrixXd>> (A));
    MatrixXd A_vec_ = Map<const MatrixXd>(A_.data(), A_.size(), 1);
    return wrap(A_vec_);
}

// [[Rcpp::export]]
IntegerMatrix Convert_integer_matrix_to_vector(const IntegerMatrix & A){
    const Map<MatrixXi> A_ (as <Map<MatrixXi>> (A));
    MatrixXi A_vec_ = Map<const MatrixXi>(A_.data(), A_.size(), 1);
    return wrap(A_vec_);
}

// [[Rcpp::export]]
NumericMatrix Convert_List_to_vector(const List & X){
    const Map<MatrixXd> X0_ (as <Map<MatrixXd>> (X[0]));
    MatrixXd A_ = MatrixXd::Constant(X0_.size(), X.length() ,0);
    for(int i=0; i!=X.length(); i++){
        Map<MatrixXd> X_vec_ (as <Map<MatrixXd>> (Convert_numeric_matrix_to_vector(X[i])));
        A_.col(i) = X_vec_;
    }
    return wrap(A_);
}


// [[Rcpp::export]]
Eigen::SparseMatrix<double> Convert_FE_to_regressor(const NumericMatrix & L, const NumericMatrix & R){
    const Map<MatrixXd> L_ (as <Map<MatrixXd>> (L));
    const Map<MatrixXd> R_ (as <Map<MatrixXd>> (R));
    int N = L_.rows();
    int T = R_.rows();
    int num_factor = L_.cols();
    
    Eigen::SparseMatrix<double> A_(N*T, (N + T) * num_factor);
    
    for(int i = 0; i != N; i++){
        for(int t = 0; t!=T; t++){
            for(int r = 0; r!= num_factor; r++){
                A_.insert(t*N + i, i*num_factor + r) = L_(i, r);
            } 
        }
    }
    for(int t = 0; t!=T; t++){
        for(int i = 0; i!= N; i++){
            for(int r = 0; r!= num_factor; r++){
                A_.insert(i + t * N, N*num_factor + t*num_factor + r) = R_(t, r);
            }  
        }
    }
  
    return A_;
}
