#include "basics.h"

// [[Rcpp::export]]
List SVT(const NumericMatrix & U, const NumericMatrix & V, 
         const NumericVector & sigma, double lambda){
    
    const Map<MatrixXd> U_ (as<Map<MatrixXd>> (U));
    const Map<MatrixXd> V_ (as<Map<MatrixXd>> (V));
    const Map<VectorXd> sigma_ (as<Map<VectorXd>> (sigma));
    
    VectorXd sigma_trunc_ = sigma_ - VectorXd::Constant(sigma_.size(), lambda);
    sigma_trunc_ = sigma_trunc_.cwiseMax(0);
    int num_positive = 0;
    for(int i=0; i!=sigma_.size(); i++){
        if(sigma_trunc_(i) > 1e-10){
            num_positive = num_positive + 1;
        }
        else{
            break;
        }
    }
    if(num_positive ==0){
        num_positive = num_positive + 1;
    }
    MatrixXd A_truc_ = U_.leftCols(num_positive) 
        * sigma_trunc_.head(num_positive).asDiagonal()
        * V_.leftCols(num_positive).transpose();
        NumericMatrix A_truc = wrap(A_truc_);
        NumericVector sigma_trunc = wrap(sigma_trunc_);
        return List::create(Named("A") = A_truc, 
                            Named("sigma") = sigma_trunc);
}
