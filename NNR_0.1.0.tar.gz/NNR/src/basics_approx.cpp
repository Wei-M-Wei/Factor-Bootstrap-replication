#include "basics.h"

// [[Rcpp::export]]
List Low_rank_appro(NumericMatrix & Theta, const int num_factor){
    
    const Map<MatrixXd> Theta_ (as<Map<MatrixXd>> (Theta));
    int N = Theta_.rows();
    int T = Theta_.cols();
    
    MatrixXd L_truc_;
    MatrixXd R_truc_;
    
    if (num_factor > 0){
        List svd_list = SVD(Theta);
        
        MatrixXd U_ =  svd_list["U_"];
        MatrixXd V_ =  svd_list["V_"];
        VectorXd sigma_ = svd_list["sigma_"];
        
        L_truc_ = U_.leftCols(num_factor);
        VectorXd sigma_truc_ = sigma_.head(num_factor);
        R_truc_ = V_.leftCols(num_factor);
        
        
        L_truc_ = L_truc_ * sigma_truc_.asDiagonal() / std::sqrt(Theta_.cols());
        R_truc_ = std::sqrt(Theta_.cols()) * R_truc_;
        
        if(sigma_truc_(0) <=2e-10){
            L_truc_.setZero();
            R_truc_.setZero();
        }
    }
    else{
        L_truc_  = MatrixXd::Constant(N, 1, 0);
        R_truc_  = MatrixXd::Constant(T, 1, 0);
    }
    
    return List::create(Named("L") = wrap(L_truc_),
                        Named("R") = wrap(R_truc_));
}


// [[Rcpp::export]]
NumericMatrix Compute_generalized_inverse(NumericMatrix & A){
    
    const Map<MatrixXd> A_ (as <Map<MatrixXd>> (A));
    
    List list_svd = SVD(A);
    MatrixXd U_ =  list_svd["U_"];
    MatrixXd V_ =  list_svd["V_"];
    VectorXd sigma_ = list_svd["sigma_"];
    
    MatrixXd sigma_inverse_ = MatrixXd::Constant(A_.cols(), A_.rows(), 0);
    for (int i = 0; i < sigma_.size(); i++){
        if (sigma_(i) > 1e-9){ 
            sigma_inverse_(i, i) = 1.0 / sigma_(i);
        }
    }
    Rcout << sigma_inverse_ << std::endl;
    MatrixXd A_ginv_ = V_ * sigma_inverse_ * U_.transpose();
    return wrap(A_ginv_);
}
