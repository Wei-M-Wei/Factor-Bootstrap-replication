# Debug why B=0, D=0 when using ESTIMATED factors vs TRUE factors

library(NNR)
library(fixest)
set.seed(42)

# Generate test data
N <- 30
T <- 20
R <- 1
beta_true <- 1.0

# True factor structure
lambda_true <- matrix(rnorm(N * R, sd = 0.5), N, R)
f_true <- matrix(rnorm(T * R, sd = 0.5), T, R)
alpha <- lambda_true %*% t(f_true)

X1 <- matrix(rnorm(N * T), N, T)
eta <- beta_true * X1 + alpha
prob <- 1 / (1 + exp(-eta))
Y <- matrix(rbinom(N * T, 1, prob), N, T)

X_list <- list(X1)

cat("=== Test 1: Using TRUE factors ===\n")
result_true <- Compute_bias_corr_logit(Y, X_list, c(beta_true), lambda_true, f_true, 0)
cat("B_est:", result_true$B_est, "\n")
cat("D_est:", result_true$D_est, "\n")
cat("beta_corr:", result_true$beta_corr, "\n\n")

cat("=== Test 2: Using estimated factors from Low_rank_appro ===\n")
# First, estimate theta using NNR or just use the true alpha
# Then decompose using Low_rank_appro
theta_true <- alpha  # Using true interactive effects

lr_decomp <- Low_rank_appro(theta_true, R)
L_est <- lr_decomp$L
R_est <- lr_decomp$R

cat("L_est dimensions:", dim(L_est), "\n")
cat("R_est dimensions:", dim(R_est), "\n")
cat("L_est range:", range(L_est), "\n")
cat("R_est range:", range(R_est), "\n\n")

# Compare true vs estimated factors
cat("Correlation between true and estimated Lambda:", cor(as.vector(lambda_true), as.vector(L_est)), "\n")
cat("Correlation between true and estimated Gamma:", cor(as.vector(f_true), as.vector(R_est)), "\n\n")

# Check if L_est * R_est' approximates alpha
alpha_reconstructed <- L_est %*% t(R_est)
cat("Alpha reconstruction error:", sqrt(mean((alpha - alpha_reconstructed)^2)), "\n\n")

result_est <- Compute_bias_corr_logit(Y, X_list, c(beta_true), L_est, R_est, 0)
cat("B_est:", result_est$B_est, "\n")
cat("D_est:", result_est$D_est, "\n")
cat("beta_corr:", result_est$beta_corr, "\n\n")

cat("=== Test 3: Check if factors are zero or constant ===\n")
cat("L_est all zeros?", all(L_est == 0), "\n")
cat("R_est all zeros?", all(R_est == 0), "\n")
cat("L_est sd:", sd(L_est), "\n")
cat("R_est sd:", sd(R_est), "\n\n")

cat("=== Test 4: Full NNRPanel_estimate ===\n")
df <- cbind(rep(1:N, each = T), rep(1:T, N), as.vector(t(Y)), as.vector(t(X1)))
result_full <- NNRPanel_estimate(
  data_frame = df,
  func = "logit",
  delta = 0.05,
  R_max = 3,
  R_true = R
)

cat("num_factor_est:", result_full$num_factor_est, "\n")
cat("beta_fe:", result_full$beta_fe, "\n")
cat("beta_corr:", result_full$beta_corr, "\n")
cat("beta_corr_sp:", result_full$beta_corr_sp, "\n")
