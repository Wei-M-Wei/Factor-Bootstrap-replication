# debug_repro.R - run minimal example with robust error capture
if (!requireNamespace("magrittr", quietly = TRUE)) install.packages("magrittr")
library(magrittr)

if (!requireNamespace("NNR", quietly = TRUE)) stop("Install package 'NNR' first")
library(NNR)

res <- tryCatch({
  dat <- NNR:::gen_data_probit(N = 30, T = 20, num_factor = 1, num_Z = 1, beta = c(0.2))
  df <- NNR:::list_to_data_frame(dat)
  cat("data.frame dims:", dim(as.data.frame(df)), "\n")
  cat("sample rows:\n"); print(head(as.data.frame(df)))
  out <- tryCatch({
    res <- NNR::NNRPanel_estimate(
      data_frame = df,
      func       = "probit",
      R_max      = 1,
      R_true     = 1,
      R_true_only = TRUE,
      s = 10,
      iter_max = 200,
      tol = 1e-6
    )
    res
  }, error = function(e){
    cat("ERROR in NNRPanel_estimate:\n")
    print(e)
    traceback()
    NULL
  })
  out
}, error = function(e){
  cat("TOP-LEVEL ERROR:\n")
  print(e)
  traceback()
  NULL
})

cat("--- sessionInfo() ---\n")
print(sessionInfo())

if (!is.null(res)) print(names(res))

cat("done\n")
