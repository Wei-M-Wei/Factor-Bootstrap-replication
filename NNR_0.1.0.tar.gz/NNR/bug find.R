# probit_test_minimal.R
# Minimal example: generate probit panel, transform, estimate with NNR::NNRPanel_estimate

# Ensure pipe operator is available
if (!requireNamespace("magrittr", quietly = TRUE)) {
  install.packages("magrittr")
}
library(magrittr)
library(NNR)
# ensure NNR is installed and load namespace-only helpers
if (!requireNamespace("NNR", quietly = TRUE)) stop("Install package 'NNR' first")

# Generate data (N, T, 1 factor, 1 covariate, true beta = 0.2)
dat <- NNR:::gen_data_probit(N = 30, T = 20, num_factor = 1, num_Z = 1, beta = c(0.2))

# Convert to long data.frame expected by NNR
df <- NNR:::list_to_data_frame(dat)

# Quick sanity print
cat("data.frame dims:", dim(as.data.frame(df)), "\n")
cat("sample rows:\n"); print(head(as.data.frame(df)))

# Run estimator (use R_true_only = TRUE to save time when R_true known)
res <- NNR::NNRPanel_estimate(
  data_frame = df,
  func       = "probit",
  R_max      = 1,
  R_true     = 1,
  R_true_only = TRUE,
  s = 10,
  iter_max = 200,
  tol = 1e-6
)
res$beta_corr
res$beta_fe
# Print key results
if (!is.null(res$beta_nnr))      cat("beta_nnr     =", formatC(res$beta_nnr, digits = 6), "\n")
if (!is.null(res$beta_fe))       cat("beta_fe     =", formatC(res$beta_fe, digits = 6), "\n")
if (!is.null(res$beta_fe_data))  cat("beta_fe_data=", formatC(res$beta_fe_data, digits = 6), "\n")
if (!is.null(res$beta_corr))     cat("beta_corr   =", formatC(res$beta_corr, digits = 6), "\n")
if (!is.null(res$beta_corr_sp))  cat("beta_corr_sp=", formatC(res$beta_corr_sp, digits = 6), "\n")
if (!is.null(res$beta_corr_data))cat("beta_corr_data=", formatC(res$beta_corr_data, digits = 6), "\n")
if (!is.null(res$beta_corr_sp_data)) cat("beta_corr_sp_data=", formatC(res$beta_corr_sp_data, digits = 6), "\n")
