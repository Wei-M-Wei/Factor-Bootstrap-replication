# ============================================================
# TOY EXAMPLE: Verify NNR Package Correctness
# ============================================================
# This script tests the NNR package with a simple simulated
# interactive factor model where we know the true parameters.

# Load the installed package
library(NNR)
getNativeSymbolInfo("_NNR_SVD", PACKAGE = "NNR")
set.seed(123)

# ============================================================
# PART 1: Test Basic C++ Functions
# ============================================================
cat("========== PART 1: Testing Basic Functions ==========\n\n")

# Test 1: SVD function
cat("Test 1: SVD function\n")
A <- matrix(c(1, 2, 3, 4, 5, 6), nrow = 2, ncol = 3)
cat("Input matrix A:\n")
print(A)

tryCatch({
  svd_result <- NNR:::SVD(A)
  cat("\nSVD result:\n")
  cat("U:\n"); print(svd_result$U)
  cat("sigma:\n"); print(svd_result$sigma)
  cat("V:\n"); print(svd_result$V)
  
  # Verify: A = U * diag(sigma) * t(V)
  A_reconstructed <- svd_result$U %*% diag(svd_result$sigma) %*% t(svd_result$V)
  cat("\nReconstruction error:", max(abs(A - A_reconstructed)), "\n")
  cat("SVD Test: PASSED ✓\n\n")
}, error = function(e) {
  cat("SVD Test: FAILED ✗\n")
  cat("Error:", e$message, "\n\n")
})

# Test 2: Low-rank approximation
cat("Test 2: Low-rank Approximation\n")
B <- matrix(rnorm(20), 4, 5)
cat("Input matrix B (4x5):\n")
print(round(B, 3))

tryCatch({
  low_rank <- NNR:::Low_rank_appro(B, num_factor = 2)
  cat("\nRank-2 approximation:\n")
  print(round(low_rank, 3))
  
  # Check rank
  svd_check <- svd(low_rank)
  effective_rank <- sum(svd_check$d > 1e-10)
  cat("\nEffective rank of approximation:", effective_rank, "\n")
  cat("Low-rank Approximation Test: PASSED ✓\n\n")
}, error = function(e) {
  cat("Low-rank Approximation Test: FAILED ✗\n")
  cat("Error:", e$message, "\n\n")
})

# Test 3: SVT (Singular Value Thresholding)
cat("Test 3: SVT (Singular Value Thresholding)\n")
tryCatch({
  svd_B <- SVD(B)
  svt_result <- SVT(svd_B$U, svd_B$V, svd_B$sigma, lambda = 0.5)
  cat("Original singular values:", round(svd_B$sigma, 3), "\n")
  cat("After soft-thresholding (lambda=0.5):\n")
  print(round(svt_result, 3))
  cat("SVT Test: PASSED ✓\n\n")
}, error = function(e) {
  cat("SVT Test: FAILED ✗\n")
  cat("Error:", e$message, "\n\n")
})

# ============================================================
# PART 2: Simple Interactive Factor Model
# ============================================================
cat("\n========== PART 2: Interactive Factor Model ==========\n\n")

# Model: Y_it ~ Bernoulli(p_it)
# logit(p_it) = X_it * beta + lambda_i * f_t
# 
# True parameters:
# - beta = 1 (single covariate)
# - 2 factors

N <- 30      # individuals
T <- 40      # time periods
R <- 2       # number of factors
beta_true <- 1.0

cat("Simulation Setup:\n")
cat("- N (individuals):", N, "\n")
cat("- T (time periods):", T, "\n")
cat("- R (factors):", R, "\n")
cat("- True beta:", beta_true, "\n\n")

# Generate factors
lambda_i <- matrix(rnorm(N * R, sd = 0.5), N, R)  # individual loadings
f_t <- matrix(rnorm(T * R, sd = 0.5), T, R)       # time factors
FE <- lambda_i %*% t(f_t)                          # interactive fixed effects

# Generate covariate (correlated with factors for endogeneity)
X <- matrix(0, N, T)
for (i in 1:N) {
  for (t in 1:T) {
    X[i, t] <- 0.3 * lambda_i[i, 1] + 0.3 * f_t[t, 1] + rnorm(1)
  }
}

# Generate outcome
index <- beta_true * X + FE
prob <- 1 / (1 + exp(-index))
Y <- matrix(rbinom(N * T, 1, as.vector(prob)), N, T)

cat("Data Generated:\n")
cat("- Y (outcome) range:", range(Y), "\n")
cat("- X (covariate) range:", round(range(X), 2), "\n")
cat("- Prob range:", round(range(prob), 2), "\n")
cat("- Fraction Y=1:", round(mean(Y), 3), "\n\n")

# Convert to data_frame format for NNRPanel_estimate
# Format: [ID, Time, Y, X1, X2, ...]
data_frame <- matrix(0, N * T, 4)
data_frame[, 1] <- rep(1:N, each = T)      # ID
data_frame[, 2] <- rep(1:T, times = N)     # Time
data_frame[, 3] <- as.vector(t(Y))         # Y
data_frame[, 4] <- as.vector(t(X))         # X

cat("Data frame created with dimensions:", dim(data_frame), "\n\n")

# ============================================================
# PART 3: Estimate the Model
# ============================================================
cat("========== PART 3: Model Estimation ==========\n\n")

cat("Running NNRPanel_estimate...\n")
cat("(This may take a moment)\n\n")

tryCatch({
  result <- NNRPanel_estimate(
    data_frame = data_frame,
    func = "logit",
    delta = 0.05,
    R_max = 5,
    R_true = R,
    s = 10,
    iter_max = 100,
    tol = 1e-6
  )
  
  # ============================================================
  # PART 4: Results
  # ============================================================
  cat("========== PART 4: RESULTS ==========\n\n")
  
  cat("TRUE PARAMETERS:\n")
  cat("  beta =", beta_true, "\n")
  cat("  R (factors) =", R, "\n\n")
  
  cat("ESTIMATED PARAMETERS:\n")
  cat("  beta_nnr =", round(result$beta_nnr[1], 4), "\n")
  cat("  Estimated R =", result$num_factor_est, "\n\n")
  
  if (!is.null(result$beta_fe)) {
    cat("  beta_fe (with R_true) =", round(result$beta_fe[1], 4), "\n")
  }
  if (!is.null(result$beta_corr)) {
    cat("  beta_corr (bias-corrected) =", round(result$beta_corr[1], 4), "\n")
  }
  if (!is.null(result$beta_corr_sp)) {
    cat("  beta_corr_sp (sample-split BC) =", round(result$beta_corr_sp[1], 4), "\n")
  }
  
  cat("\nDATA-DRIVEN RANK ESTIMATES:\n")
  cat("  beta_fe_data =", round(result$beta_fe_data[1], 4), "\n")
  cat("  beta_corr_data =", round(result$beta_corr_data[1], 4), "\n")
  cat("  beta_corr_sp_data =", round(result$beta_corr_sp_data[1], 4), "\n")
  
  # ============================================================
  # PART 5: Evaluation
  # ============================================================
  cat("\n========== PART 5: EVALUATION ==========\n\n")
  
  # Estimation errors
  errors <- c(
    NNR = abs(result$beta_nnr[1] - beta_true),
    FE = if (!is.null(result$beta_fe)) abs(result$beta_fe[1] - beta_true) else NA,
    BC = if (!is.null(result$beta_corr)) abs(result$beta_corr[1] - beta_true) else NA,
    SSBC = if (!is.null(result$beta_corr_sp)) abs(result$beta_corr_sp[1] - beta_true) else NA,
    FE_data = abs(result$beta_fe_data[1] - beta_true),
    BC_data = abs(result$beta_corr_data[1] - beta_true),
    SSBC_data = abs(result$beta_corr_sp_data[1] - beta_true)
  )
  
  cat("Absolute Estimation Errors:\n")
  for (name in names(errors)) {
    if (!is.na(errors[name])) {
      cat(sprintf("  %s: %.4f\n", name, errors[name]))
    }
  }
  
  # Rank estimation
  cat("\nRank Estimation:\n")
  cat("  True R:", R, "\n")
  cat("  Estimated R:", result$num_factor_est, "\n")
  cat("  Rank correctly estimated:", result$num_factor_est == R, "\n")
  
  # Overall assessment
  cat("\n========== OVERALL ASSESSMENT ==========\n\n")
  
  best_error <- min(errors, na.rm = TRUE)
  if (best_error < 0.3) {
    cat("✓ EXCELLENT: Best estimate within 0.3 of true beta\n")
  } else if (best_error < 0.5) {
    cat("✓ GOOD: Best estimate within 0.5 of true beta\n")
  } else {
    cat("⚠ WARNING: Estimates may need larger sample size\n")
  }
  
  if (result$num_factor_est == R) {
    cat("✓ RANK: Correctly estimated number of factors\n")
  } else {
    cat("⚠ RANK: Estimated", result$num_factor_est, "factors (true:", R, ")\n")
  }
  
  cat("\n✓ PACKAGE VERIFICATION COMPLETE!\n")
  
}, error = function(e) {
  cat("ERROR in NNRPanel_estimate:\n")
  cat(e$message, "\n")
  cat("\nPlease ensure the package is properly installed:\n")
  cat("  source('rebuild.R')\n")
  cat("  library(NNR)\n")
})
