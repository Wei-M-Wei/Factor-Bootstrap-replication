# Detailed debug of bias correction components
# We'll call the C++ functions directly to see intermediate values

library(NNR)
set.seed(42)

# Generate small test data
N <- 30
T <- 20
R <- 1
beta_true <- 1.0

# Simple factor structure
lambda <- matrix(rnorm(N * R, sd = 0.5), N, R)
f <- matrix(rnorm(T * R, sd = 0.5), T, R)
alpha <- lambda %*% t(f)

# Covariate
X1 <- matrix(rnorm(N * T), N, T)

# Generate Y
eta <- beta_true * X1 + alpha
prob <- 1 / (1 + exp(-eta))
Y <- matrix(rbinom(N * T, 1, prob), N, T)

cat("=== Data Summary ===\n")
cat("N =", N, ", T =", T, ", R =", R, "\n")
cat("Y mean:", mean(Y), "\n")
cat("X1 range:", range(X1), "\n\n")

# Convert to format expected by NNR functions
X_list <- list(X1)

# Estimate beta (use true values as starting point for simplicity)
beta_est <- c(1.0)  # Approximate estimate
L_est <- lambda     # Use true factors for testing
R_est <- f

cat("=== Computing derivatives manually ===\n")

# Compute linear index
index <- L_est %*% t(R_est)
for (k in 1:length(beta_est)) {
  index <- index + X_list[[k]] * beta_est[k]
}

# First order: Y - p where p = 1/(1+exp(-index))
p <- 1 / (1 + exp(-index))
first_order <- Y - p
cat("first_order range:", range(first_order), "\n")
cat("first_order mean:", mean(first_order), "\n")
cat("first_order sd:", sd(first_order), "\n\n")

# Second order: p * (1-p) 
second_order <- p * (1 - p)
second_order[second_order < 1e-10] <- 1e-10
cat("second_order range:", range(second_order), "\n")
cat("second_order mean:", mean(second_order), "\n")
cat("second_order sd:", sd(second_order), "\n\n")

# Third order: p*(1-p)*(2p-1) = second_order * (2p-1)
third_order <- second_order * (2 * p - 1)
cat("third_order range:", range(third_order), "\n")
cat("third_order mean:", mean(third_order), "\n")
cat("third_order sd:", sd(third_order), "\n\n")

cat("=== Computing X residualization manually ===\n")
# Project X onto factor space: X_tilde = X - projection
# The projection uses weighted least squares with weights = second_order

# For simplicity, compute unweighted projection first
# X = Lambda * delta' + Gamma * mu' + X_tilde
# where delta, mu are coefficients

library(fixest)

# Prepare data for fixest
df_proj <- data.frame(
  X = as.vector(X1),
  id = factor(rep(1:N, T)),
  time = factor(rep(1:T, each = N)),
  Lambda1 = rep(lambda[,1], T),
  Gamma1 = rep(f[,1], each = N),
  W = as.vector(second_order)
)

# Weighted regression
fit <- feols(X ~ 0 | time[Lambda1] + id[Gamma1], data = df_proj, weights = ~W)
X_res <- matrix(residuals(fit), N, T)

cat("X_res (residualized X) range:", range(X_res), "\n")
cat("X_res mean:", mean(X_res), "\n")
cat("X_res sd:", sd(X_res), "\n")
cat("Original X sd:", sd(X1), "\n")
cat("Ratio:", sd(X_res)/sd(X1), "\n\n")

cat("=== Testing W matrix (Information matrix) ===\n")
# W = (1/NT) * sum_{i,t} second_order[i,t] * X_res[i,t]^2
W_manual <- sum(second_order * X_res^2) / (N * T)
cat("W (manual calculation):", W_manual, "\n\n")

cat("=== Testing B bias term ===\n")
# B term - bias from time effects (individual-specific)
# B = -1/N * sum_i { sum_t [ (d1*d2 + 0.5*d3) * X_res * gamma' * H_i^{-1} * gamma ] }

B_manual <- 0
for (i in 1:N) {
  # Compute H_i = sum_t second_order[i,t] * gamma_t * gamma_t'
  H_i <- sum(second_order[i, ] * f[, 1]^2)
  H_i_inv <- 1 / (H_i + 1e-8)  # Add regularization
  
  for (t in 1:T) {
    quad_term <- f[t, 1]^2 * H_i_inv
    bias_term <- (first_order[i, t] * second_order[i, t] + 0.5 * third_order[i, t]) * X_res[i, t] * quad_term
    B_manual <- B_manual + bias_term
  }
}
B_manual <- -B_manual / N
cat("B (manual calculation):", B_manual, "\n")

cat("\n=== Testing D bias term ===\n")
# D term - bias from individual effects (time-specific)
# D = -1/T * sum_t { sum_i [ (d1*d2 + 0.5*d3) * X_res * lambda' * H_t^{-1} * lambda ] }

D_manual <- 0
for (t in 1:T) {
  # Compute H_t = sum_i second_order[i,t] * lambda_i * lambda_i'
  H_t <- sum(second_order[, t] * lambda[, 1]^2)
  H_t_inv <- 1 / (H_t + 1e-8)  # Add regularization
  
  for (i in 1:N) {
    quad_term <- lambda[i, 1]^2 * H_t_inv
    bias_term <- (first_order[i, t] * second_order[i, t] + 0.5 * third_order[i, t]) * X_res[i, t] * quad_term
    D_manual <- D_manual + bias_term
  }
}
D_manual <- -D_manual / T
cat("D (manual calculation):", D_manual, "\n")

cat("\n=== Bias Correction ===\n")
W_inv <- 1 / W_manual
bias_correction <- (1/T) * W_inv * B_manual + (1/N) * W_inv * D_manual
cat("Total bias correction:", bias_correction, "\n")
cat("beta_corrected = beta_mle + correction =", beta_est + bias_correction, "\n")

cat("\n=== Now calling C++ Compute_bias_corr_logit ===\n")
result <- Compute_bias_corr_logit(Y, X_list, beta_est, L_est, R_est, 0)
cat("C++ B_est:", result$B_est, "\n")
cat("C++ D_est:", result$D_est, "\n")
cat("C++ W_est:", result$W_est, "\n")
cat("C++ beta_corr:", result$beta_corr, "\n")

cat("\n=== Comparison ===\n")
cat("Manual B:", B_manual, "vs C++ B:", result$B_est, "\n")
cat("Manual D:", D_manual, "vs C++ D:", result$D_est, "\n")
cat("Manual W:", W_manual, "vs C++ W:", result$W_est, "\n")
