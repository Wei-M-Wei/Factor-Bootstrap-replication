library(pkgload)
load_all()
set.seed(42)

# Probit
cat('--- PROBIT RUN ---\n')
dat_p <- gen_data_probit(N=30, T=30, num_factor=1, num_Z=1, beta=c(0.2))
dl_p <- data_frame_to_list(list_to_data_frame(dat_p))
X_p <- dl_p$X; Y_p <- dl_p$Y
fitp <- fit_probit(X_p, Y_p, phi=1, s=1, iter_max=10, tol=1e-6)
LRp <- Low_rank_appro(fitp$Theta_est,1)
fe_p <- MLE_probit(X_p, Y_p, fitp$beta_est, LRp$L, LRp$R, s=1, iter_max=20, tol=1e-6)
so_p <- Compute_second_order_probit_with_LR(X_p, Y_p, fe_p$beta_est, fe_p$L_est, fe_p$R_est)
cat('Probit Create_X_res try...\n')
tryCatch({ xr_p <- Create_X_res(X_p, fe_p$L_est, fe_p$R_est, so_p); cat('Probit Create_X_res succeeded\n') }, error=function(e){cat('Probit Create_X_res ERROR:\n'); cat(conditionMessage(e), '\n')})

# Logit
cat('--- LOGIT RUN ---\n')
dat_l <- gen_data_logit(N=30, T=30, num_factor=1, num_Z=1, beta=c(0.2))
dl_l <- data_frame_to_list(list_to_data_frame(dat_l))
X_l <- dl_l$X; Y_l <- dl_l$Y
fitl <- fit_logit(X_l, Y_l, phi=1, s=1, iter_max=10, tol=1e-6)
LRl <- Low_rank_appro(fitl$Theta_est,1)
fe_l <- MLE_logit(X_l, Y_l, fitl$beta_est, LRl$L, LRl$R, s=1, iter_max=20, tol=1e-6)
so_l <- Compute_second_order_logit_with_LR(X_l, fe_l$beta_est, fe_l$L_est, fe_l$R_est)
cat('Logit Create_X_res try...\n')
tryCatch({ xr_l <- Create_X_res(X_l, fe_l$L_est, fe_l$R_est, so_l); cat('Logit Create_X_res succeeded\n') }, error=function(e){cat('Logit Create_X_res ERROR:\n'); cat(conditionMessage(e), '\n')})

cat('Done\n')